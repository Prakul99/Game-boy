package comp3350.group1.tests.acceptance;

import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import comp3350.group1.R;
import comp3350.group1.presentation.FirstScreen;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;


@RunWith(AndroidJUnit4.class)
@LargeTest
public class FirstScreenAcceptanceTests {

    @Rule
    public ActivityTestRule<FirstScreen> firstScreenActivity = new ActivityTestRule<>(FirstScreen.class);

    @Test
    public void testMainScreen()
    {
        onView(withText("CODE BOY")).check(matches(isDisplayed()));
        onView(withId(R.id.newGame)).check(matches(isDisplayed()));
        onView(withId(R.id.loadGameButton)).check(matches(isDisplayed()));
        onView(withId(R.id.quitGame)).check(matches(isDisplayed()));
        onView(withId(R.id.leader_Board)).check(matches(isDisplayed()));
    }

}

