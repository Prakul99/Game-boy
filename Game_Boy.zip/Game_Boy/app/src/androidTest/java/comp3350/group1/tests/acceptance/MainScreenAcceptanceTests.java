package comp3350.group1.tests.acceptance;

import android.os.SystemClock;
import android.view.View;

import androidx.test.espresso.UiController;
import androidx.test.espresso.ViewAction;
import androidx.test.rule.ActivityTestRule;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;

import comp3350.group1.R;
import comp3350.group1.presentation.FirstScreen;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isClickable;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;

public class MainScreenAcceptanceTests
{
    @Rule
    public ActivityTestRule<FirstScreen> firstScreenActivity = new ActivityTestRule<>(FirstScreen.class);

    @Test
    public void testNewGame() {
        onView(withText("New Game")).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        for (int i = 0; i < 10; i++) {
            onView(withId(R.id.CompileButton)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
            SystemClock.sleep(100);
        }

        onView(withText("Currency: 10")).check(matches(isDisplayed()));
        onView(withText("Per Second: 0" + "\nGain On Click: 1")).check(matches(isDisplayed()));

        onData(anything()).inAdapterView(withId(R.id.upgradeListView)).atPosition(0).onChildView(withId(R.id.buyBtn)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        onView(withText("Currency: 0")).check(matches(isDisplayed()));
        onView(withText("Per Second: 1" + "\nGain On Click: 1")).check(matches(isDisplayed()));
        for (int i = 0; i < 100; i++) {
            onView(withId(R.id.CompileButton)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        }
        for (int i = 0; i < 4; i++) {
            onData(anything()).inAdapterView(withId(R.id.upgradeListView)).atPosition(0).onChildView(withId(R.id.buyBtn)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        }
        onView(withText("Congratulations!")).check(matches(isDisplayed()));
        onView(withId(R.id.buttonAction)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        for (int i = 0; i < 4; i++) {
            onData(anything()).inAdapterView(withId(R.id.upgradeListView)).atPosition(0).onChildView(withId(R.id.sellBtn)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        }
        onView(withId(R.id.clickUpgradeBtn)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        onData(anything()).inAdapterView(withId(R.id.upgradeListView)).atPosition(0).onChildView(withId(R.id.buyBtn)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        onData(anything()).inAdapterView(withId(R.id.upgradeListView)).atPosition(0).onChildView(withId(R.id.upgradeInfoBtn)).perform(new MainScreenAcceptanceTests.CallOnClickAction());
        onView(withText("Upgrade Info")).check(matches(isDisplayed()));
    }
    public class CallOnClickAction implements ViewAction
    {
        @Override
        public Matcher<View> getConstraints() {
            return allOf(isClickable(), isDisplayed());
        }

        @Override
        public String getDescription() {
            return "CallOnClick";
        }

        @Override
        public void perform(UiController uiController, View view) {
            view.callOnClick();
        }
    }

}
