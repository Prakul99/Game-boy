package comp3350.group1.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import comp3350.group1.tests.acceptance.FirstScreenAcceptanceTests;
import comp3350.group1.tests.acceptance.LeaderboardAcceptanceTests;
import comp3350.group1.tests.acceptance.LoadGameAcceptanceTests;
import comp3350.group1.tests.acceptance.MainScreenAcceptanceTests;

@RunWith(Suite.class)
@Suite.SuiteClasses({FirstScreenAcceptanceTests.class, LeaderboardAcceptanceTests.class, LoadGameAcceptanceTests.class, MainScreenAcceptanceTests.class})
public class RunAcceptanceTests
{
    public RunAcceptanceTests()
    {
        System.out.println("Sample Acceptance tests");
    }
}
