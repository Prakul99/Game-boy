package comp3350.group1.tests.acceptance;

import androidx.test.rule.ActivityTestRule;

import org.junit.Rule;
import org.junit.Test;

import comp3350.group1.R;
import comp3350.group1.presentation.FirstScreen;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.anything;

public class LeaderboardAcceptanceTests {

    @Rule
    public ActivityTestRule<FirstScreen> firstScreenActivity = new ActivityTestRule<>(FirstScreen.class);

    @Test
    public void testLeaderBoard()
    {
        onView(withText("LEADERBOARD")).perform(click());
        onView(withText("Leaderboard")).check(matches(isDisplayed()));

        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withId(R.id.imageView4));

        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withId(R.id.Rank));
        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withId(R.id.Currency));
        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withId(R.id.savedTime));

        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withText("1"));
        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withText("Net Worth:"));
        onData(anything()).inAdapterView(withId(R.id.loadGameList)).atPosition(0).onChildView(withText("Play Time:"));
    }
}
