package comp3350.group1.business;

import java.util.Iterator;
import java.util.List;

import comp3350.group1.application.Services;
import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;
import comp3350.group1.persistence.IDataAccess;

/**
 * Accesses the data layer to get information about upgrades.
 */
public class AccessUpgrades
{
    // Our database access.
    IDataAccess data;

    /**
     *  Initializes our database access
     */
    public AccessUpgrades()
    {
        data = Services.getDataAccess();
    }

    /**
     * Gets information about all the upgrades in persistent storage.
     * @param upgradesList the list we will fill with upgrades data.
     */
    public void getAllRateUpgrades(List<IPurchasableEffect> upgradesList)
    {
        data.getAllRateUpgrades(upgradesList);
    }

    public void getAllClickUpgrades(List<IPurchasableEffect> upgradeList)
    {
        data.getAllClickUpgrades(upgradeList);
    }

    /**
     * Get all of the Upgrades that are unlocked in the given GameState.
     * @param upgrades the list to fill with unlocked Upgrades.
     * @param state the state to check for RateUpgrade unlocking.
     */
    public void getUnlockedRateUpgrades(List<IPurchasableEffect> upgrades, GameState state)
    {
        getAllRateUpgrades(upgrades);

        // Iterator used for safety purposes (removing)
        Iterator<IPurchasableEffect> upgradeIterator = upgrades.iterator();
        while(upgradeIterator.hasNext())
        {
            IPurchasableEffect upgrade = upgradeIterator.next();
            if (upgrade.getType() != IPurchasableEffect.Type.Rate || !upgrade.isUnlocked(state))
                upgradeIterator.remove();
        }
    }

    public void getUnlockedClickUpgrades(List<IPurchasableEffect> clickUpgrades, GameState state)
    {
        getAllClickUpgrades(clickUpgrades);

        // Iterator used for safety purposes (removing)
        Iterator<IPurchasableEffect> upgradeIterator = clickUpgrades.iterator();
        while(upgradeIterator.hasNext())
        {
            IPurchasableEffect upgrade = upgradeIterator.next();
            if(upgrade.getType() != IPurchasableEffect.Type.Click || !upgrade.isUnlocked(state))
                upgradeIterator.remove();
        }
    }
}
