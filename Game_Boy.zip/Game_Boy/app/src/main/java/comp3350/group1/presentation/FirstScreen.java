package comp3350.group1.presentation;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import comp3350.group1.R;
import comp3350.group1.application.Services;
import comp3350.group1.business.AccessGameState;
import comp3350.group1.objects.GameState;

/**
 * This screen is our Main Menu (Title Screen).
 * We have the ability to create a New Game, Load a saved game, view the Leaderboard, and Quit.
 */
public class FirstScreen extends AppCompatActivity
{
    /**
     * Called on creation of the activity.
     * We do our interface functionality in here.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        copyDatabaseToDevice();
        setContentView(R.layout.activity_first_screen);

        // If this is null, it means that onCreate has never been called for this activity
        // - Because of this, we want to initialize our database access
        if(savedInstanceState == null)
            Services.createDataAccess(Services.DataStorage.Database);

        AccessGameState access = new AccessGameState();

        // Button to start a new game.
        Button newGameButton = findViewById(R.id.newGame);
        // Create new Intent for the MainActivity
        newGameButton.setOnClickListener(view -> {
            int ID = access.createNewGameState();
            Intent intent = new Intent(this, MainActivity.class);

            Bundle b = new Bundle();
            b.putInt(GameState.STATE_ID_KEY, ID);

            intent.putExtras(b);
            startActivity(intent);
        });

        // Button to show the list of GameStates to load from.
        Button loadGameButton = (Button) findViewById(R.id.loadGameButton);
        loadGameButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, LoadGame.class);
            startActivity(intent);
        });

        // Button to show the leaderboard.
        Button leaderBoardButton = findViewById(R.id.leader_Board);
        leaderBoardButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, LeaderBoard.class);
            startActivity(intent);
        });

        // Button to exit the app
        Button exitButton = findViewById(R.id.quitGame);
        exitButton.setOnClickListener(view -> {
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        });
    }


    /**
     * Copy the database to the device if it does not exist.
     * This will only happen once when first run.
     */
    private void copyDatabaseToDevice()
    {
        final String DB_PATH = "db";

        String[] assetNames;
        Context context = getApplicationContext();
        File dataDirectory = context.getDir(DB_PATH, Context.MODE_PRIVATE);
        AssetManager assetManager = getAssets();

        try
        {
            assetNames = assetManager.list(DB_PATH);
            for(int i = 0; i < assetNames.length; i++)
                assetNames[i] = DB_PATH + "/" + assetNames[i];

            copyAssetsToDirectory(assetNames, dataDirectory);
            Services.setDBPathName(dataDirectory.toString() + "/" + Services.dbName);
        }
        catch(IOException ignored) { }
    }

    private void copyAssetsToDirectory(String[] assets, File directory) throws IOException
    {
        AssetManager assetManager = getAssets();

        for(String asset : assets)
        {
            String[] components = asset.split("/");
            String copyPath = directory.toString() + "/" + components[components.length - 1];
            char[] buffer = new char[1024];
            int count;

            File outFile = new File(copyPath);

            if(!outFile.exists())
            {
                InputStreamReader in = new InputStreamReader(assetManager.open(asset));
                FileWriter out = new FileWriter(outFile);

                count = in.read(buffer);
                while(count != -1)
                {
                    out.write(buffer, 0, count);
                    count = in.read(buffer);
                }

                out.close();
                in.close();
            }
        }
    }
}