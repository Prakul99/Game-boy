package comp3350.group1.objects;

/**
 * This class holds information that is checked to determine if the RateUpgrade it is linked to
 * can be unlocked, given a state.
 */

public class UnlockRule
{
    // This is set to true when an item is unlocked.
    private boolean hasBeenUnlocked = false;
    // Invalidates hasBeenUnlocked if the provided GameState ever changes.
    private int cachedStateId = -1;

    private final double requiredPerSecond;
    private final double requiredClickBonus;
    private final long requiredNetWorth;
    private final int requiredUpgradeId;
    private final int requiredQuantity;

    public UnlockRule(double perSecond, double clickBonus, long netWorth, int upgradeId, int quantity)
    {
        this.requiredPerSecond = perSecond;
        this.requiredClickBonus = clickBonus;
        this.requiredNetWorth = netWorth;
        this.requiredUpgradeId = upgradeId;
        this.requiredQuantity = quantity;
    }

    /**
     * Check whether the rules are satisfied.
     * @param state the GameState to check for unlock conditions.
     * @return whether the UnlockRule is satisfied.
     */
    public boolean isUnlocked(GameState state)
    {
        // Invalidate the cache if GameState changes (e.g., started or loaded a different game).
        if(state.getId() != cachedStateId)
            hasBeenUnlocked = false;

        // Shortcut if already unlocked in the currently known game.
        if(hasBeenUnlocked && state.getId() == cachedStateId)
            return true;

        if(requiredPerSecond > 0 && state.getCurrencyPerSecond() < requiredPerSecond)
            return false;
        else if(requiredClickBonus > 0 && state.getClickBonus() < requiredClickBonus)
            return false;
        else if(requiredNetWorth > 0 && state.getNetWorth() < requiredNetWorth)
            return false;
        else if(requiredUpgradeId > 0 && state.getUpgradeQuantity(requiredUpgradeId) < requiredQuantity)
            return false;
        else
        {
            hasBeenUnlocked = true;
            cachedStateId = state.getId();
            return true;
        }
    }
}