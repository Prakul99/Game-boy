package comp3350.group1.business;

import java.util.Timer;
import java.util.TimerTask;

import comp3350.group1.objects.GameState;

/**
 * Handles auto-saving for a given GameState.
 */
public class GameStateAutoSaver
{
    // 2 minutes
    private final static long AUTOSAVE_FREQUENCY_MILLIS_DEFAULT = (1000 * 60 * 2);
    private final long AUTOSAVE_FREQUENCY_MILLIS;
    private boolean enabled;
    private Timer timer;

    private boolean hasSavedSinceLastCheck;
    private GameState state;

    /**
     * @param isEnabled if auto-saving is enabled.
     * @param state     the GameState to auto-save.
     */
    public GameStateAutoSaver(boolean isEnabled, GameState state)
    {
        this(isEnabled, state, AUTOSAVE_FREQUENCY_MILLIS_DEFAULT);
    }

    /**
     * @param isEnabled if auto-saving is enabled.
     * @param state     the GameState to auto-save.
     */
    public GameStateAutoSaver(boolean isEnabled, GameState state, long autoSaveTimeMillis)
    {
        if(state == null) throw new IllegalArgumentException("State cannot be null");
        if(autoSaveTimeMillis <= 0) throw new IllegalArgumentException("Autosave time must be greater than 0: " + autoSaveTimeMillis);

        this.state = state;
        this.enabled = false;

        this.AUTOSAVE_FREQUENCY_MILLIS = autoSaveTimeMillis;

        if(isEnabled)
            enable();

        hasSavedSinceLastCheck = false;
    }

    /**
     * Lets us know if the game has been auto - saved since this method was last queried.
     * @return whether the game has saved since our last check.
     */
    public boolean hasSavedSinceLastCheck()
    {
        if(hasSavedSinceLastCheck)
        {
            hasSavedSinceLastCheck = false;
            return true;
        }
        return false;
    }

    /**
     * @return whether the auto-saver is enabled.
     */
    public boolean isEnabled()
    {
        return enabled;
    }

    /**
     * Enables the auto-saver.
     * We start timer and auto-save at a given frequency.
     */
    public void enable()
    {
        if(enabled) throw new IllegalStateException("Timer is already enabled");

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                new AccessGameState().saveGame(state);
                hasSavedSinceLastCheck = true;
            }
        },
        AUTOSAVE_FREQUENCY_MILLIS,
        AUTOSAVE_FREQUENCY_MILLIS);

        enabled = true;
    }

    /**
     * Disables auto-saving.
     */
    public void disable()
    {
        if(!enabled) throw new IllegalStateException("Timer is already disabled");

        timer.cancel();
        timer = null;

        enabled = false;
    }
}
