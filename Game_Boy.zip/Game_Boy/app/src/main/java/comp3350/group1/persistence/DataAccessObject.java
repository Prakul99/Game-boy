package comp3350.group1.persistence;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLWarning;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import comp3350.group1.objects.GameState;
import comp3350.group1.objects.ClickUpgrade;
import comp3350.group1.objects.IPurchasableEffect;
import comp3350.group1.objects.RateUpgrade;
import comp3350.group1.objects.UnlockRule;

public class DataAccessObject implements IDataAccess
{
    private Statement st1, st2, st3;
    private Connection c1;
    private ResultSet rs2, rs3, rs4;

    private String dbType;

    private List<RateUpgrade> rateUpgrades;
    private List<ClickUpgrade> clickUpgrades;

    private String cmdString;
    private int updateCount;

    private String dbPath;

    public DataAccessObject(String dbPath)
    {
        this.dbPath = dbPath;
    }

    /**
     * Initializes our data access
     */
    public void open()
    {
        String url;
        try
        {
            // Setup for HSQL
            dbType = "HSQL";
            Class.forName("org.hsqldb.jdbcDriver").newInstance();
            url = "jdbc:hsqldb:file:" + dbPath; // stored on disk mode
            c1 = DriverManager.getConnection(url, "SA", "");
            st1 = c1.createStatement();
            st2 = c1.createStatement();
            st3 = c1.createStatement();
        }
        catch(SQLException | ClassNotFoundException e)
        {
            processSQLError(e);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }

        // Initialize the list of rateUpgrades from the database.
        RateUpgrade rateUpgrade;
        int uID;
        String uName;
        double uPerSecond;
        int uBaseCost;
        double uCostMultiplier;
        // Variables for initializing each UnlockRule for Upgrades.
        UnlockRule rule;
        double lockPerSecond;
        double lockClickBonus;
        long lockNetWorth;
        int lockUpgradeID;
        int lockUpgradeCount;

        rateUpgrades = new ArrayList<>();
        try
        {
            // We perform a left outer join on UnlockConditions, since if a tuple corresponding
            // to some ID is null, it is considered to be unlocked by default. Getting numeric
            // values from a null result returns 0, which we can use for the UnlockRule object.
            cmdString = "Select Upgrades.UpgradeID, PerSecond, BaseCost, CostMultiplier, Name, " +
                        "ReqPerSecond, ReqClickBonus, ReqNetWorth, ReqUpgradeID, ReqUpgradeCount" +
                        " from Upgrades" +
                        " inner join RateUpgrades on Upgrades.UpgradeID=RateUpgrades.UpgradeID" +
                        " left outer join UnlockConditions on Upgrades.UpgradeID=UnlockConditions.UpgradeID";
            rs2 = st1.executeQuery(cmdString);
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
        try
        {
            while(rs2.next())
            {
                uID = rs2.getInt("UpgradeID");
                uName = rs2.getString("Name");
                uPerSecond = rs2.getDouble("PerSecond");
                uBaseCost = rs2.getInt("BaseCost");
                uCostMultiplier = rs2.getDouble("CostMultiplier");

                lockPerSecond = rs2.getDouble("ReqPerSecond");
                lockClickBonus = rs2.getDouble("ReqClickBonus");
                lockNetWorth = rs2.getLong("ReqNetWorth");
                lockUpgradeID = rs2.getInt("ReqUpgradeID");
                lockUpgradeCount = rs2.getInt("ReqUpgradeCount");

                rule = new UnlockRule(lockPerSecond, lockClickBonus, lockNetWorth, lockUpgradeID, lockUpgradeCount);
                rateUpgrade = new RateUpgrade(uID, uName, uPerSecond, uBaseCost, uCostMultiplier, rule);
                rateUpgrades.add(rateUpgrade);
            }
        }
        catch(Exception e)
        {
            processSQLError(e);
        }

        // Initialize the list of ClickUpgrades from the database.
        ClickUpgrade clickUpgrade;
        int muClickBonus;

        clickUpgrades = new ArrayList<>();
        try
        {
            cmdString = "Select Upgrades.UpgradeID, ClickBonus, BaseCost, CostMultiplier, Name, " +
                        "ReqPerSecond, ReqClickBonus, ReqNetWorth, ReqUpgradeID, ReqUpgradeCount" +
                        " from Upgrades" +
                        " inner join ClickUpgrades on Upgrades.UpgradeID=ClickUpgrades.UpgradeID" +
                        " left outer join UnlockConditions on Upgrades.UpgradeID=UnlockConditions.UpgradeID";
            rs2 = st1.executeQuery(cmdString);
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
        try
        {
            while(rs2.next())
            {
                uID = rs2.getInt("UpgradeID");
                uName = rs2.getString("Name");
                muClickBonus = rs2.getInt("ClickBonus");
                uBaseCost = rs2.getInt("BaseCost");
                uCostMultiplier = rs2.getDouble("CostMultiplier");

                lockPerSecond = rs2.getDouble("ReqPerSecond");
                lockClickBonus = rs2.getDouble("ReqClickBonus");
                lockNetWorth = rs2.getLong("ReqNetWorth");
                lockUpgradeID = rs2.getInt("ReqUpgradeID");
                lockUpgradeCount = rs2.getInt("ReqUpgradeCount");

                rule = new UnlockRule(lockPerSecond, lockClickBonus, lockNetWorth, lockUpgradeID, lockUpgradeCount);
                clickUpgrade = new ClickUpgrade(uID, uName, muClickBonus, uBaseCost, uCostMultiplier, rule);
                clickUpgrades.add(clickUpgrade);
            }
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
    }

    /**
     * Query the database for game states.
     * @return a list of GameStates.
     */
    private List<GameState> queryGameStates()
    {
        // Import the game states from the database.
        GameState gameState;
        int sID;
        java.sql.Timestamp startTime;
        java.sql.Timestamp savedTime;
        long sCurrency;
        long sNetWorth;
        int currentUID;
        int currentQuantity;
        int currentMUID;
        int currentMQuantity;

        //list of all game states stored in "DB"; represents our multiple saved states
        List<GameState> states = new ArrayList<>();
        try
        {
            cmdString = "Select * from GameStates";
            rs2 = st1.executeQuery(cmdString);
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
        try
        {
            while(rs2.next())
            {
                sID = rs2.getInt("StateID");
                startTime = rs2.getTimestamp("StartTime");
                savedTime = rs2.getTimestamp("SavedTime");
                sCurrency = rs2.getLong("Currency");
                sNetWorth = rs2.getLong("NetWorth");
                // Need to make a new array each time to keep them separate.
                HashMap<IPurchasableEffect, Integer> purchasedMap = new HashMap<>();

                cmdString = "Select StateID, UpgradeID, Quantity" +
                            " From StateUpgrades Inner Join RateUpgrades" +
                            " On StateUpgrades.UpgradeID=RateUpgrades.UpgradeID" +
                            " Where StateID=" + sID;
                rs3 = st2.executeQuery(cmdString);
                while(rs3.next())
                {
                    currentUID = rs3.getInt("UpgradeID");
                    currentQuantity = rs3.getInt("Quantity");
                    purchasedMap.put(getRateUpgrade(currentUID), currentQuantity);
                }

                cmdString = "Select StateID, UpgradeID, Quantity" +
                            " From StateUpgrades Inner Join ClickUpgrades" +
                            " On StateUpgrades.UpgradeID=ClickUpgrades.UpgradeID" +
                            " Where StateID=" + sID;
                rs4 = st3.executeQuery(cmdString);
                while(rs4.next())
                {
                    currentMUID = rs4.getInt("UpgradeID");
                    currentMQuantity = rs4.getInt("Quantity");
                    purchasedMap.put(getClickUpgrade(currentMUID), currentMQuantity);
                }

                gameState = new GameState(sID, startTime, savedTime, sCurrency, sNetWorth, purchasedMap);
                states.add(gameState);
            }
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
        return states;
    }

    /**
     * Remove a game state from the database.
     * @param id The StateID to be deleted.
     */
    @Override
    public void deleteSaveGame(int id)
    {
        if(id < 0) throw new IllegalArgumentException("ID must not be negative: " + id);
        try
        {
            cmdString = "Delete from StateUpgrades where StateID=" + id;
            updateCount = st1.executeUpdate(cmdString);
            checkWarning(st1, updateCount);

            cmdString = "Delete from GameStates where StateID=" + id;
            updateCount = st1.executeUpdate(cmdString);
            checkWarning(st1, updateCount);
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
    }

    /**
     * Closes our data access
     */
    @Override
    public void close()
    {
        try
        {
            cmdString = "shutdown compact";
            rs2 = st1.executeQuery(cmdString);
            c1.close();
        }
        catch(Exception e)
        {
            processSQLError(e);
        }
        System.out.println("Closed " + dbType + "database ");
    }

    /**
     * @param id The ID of upgrade we want information about
     * @return The upgrade data of the given type
     */
    private RateUpgrade getRateUpgrade(int id)
    {
        RateUpgrade result = null;
        for(RateUpgrade upgrade : rateUpgrades)
            if(id == upgrade.getId() && upgrade.getType()== IPurchasableEffect.Type.Rate)
                result = upgrade;

        return result;
    }

    /**
     * @param id The ID of upgrade we want information about
     * @return The ClickUpgrade data of the given type
     */
    private ClickUpgrade getClickUpgrade(int id)
    {
        ClickUpgrade result = null;
        for(ClickUpgrade clickUpgrade : clickUpgrades)
            if(id == clickUpgrade.getId() && clickUpgrade.getType()== IPurchasableEffect.Type.Click)
                result = clickUpgrade;

        return result;
    }

    /**
     * Fills a given list with all rateUpgrades in persistent storage
     *
     * @param result The list to fill with all rateUpgrades
     */
    @Override
    public void getAllRateUpgrades(List<IPurchasableEffect> result)
    {
        result.clear();
        result.addAll(rateUpgrades);
    }

    /**
     * Fills a given list with all manual rateUpgrades in persistent storage.
     * @param result The list to fill with all ClickUpgrades.
     */
    @Override
    public void getAllClickUpgrades(List<IPurchasableEffect> result) {
        result.clear();
        result.addAll(clickUpgrades);
    }

    /**
     *
     * @param id the ID of the game state we want
     * @return the game state with given ID
     */
    @Override
    public GameState getGameState(int id)
    {
        if(id < 0 ) throw new IllegalArgumentException("ID must not be negative: " + id);

        GameState result = null;
        for(GameState s : queryGameStates())
            if(s.getId() == id )
                result = s;

        return result;
    }

    /**
     * creates a new game state
     *
     * @return ID of the newly created game state
     */
    @Override
    public int createNewGameState()
    {
        int largest = 0;
        List<GameState> gameStates = queryGameStates();
        for(GameState s : gameStates)
            if(s.getId() >= largest)
                largest = s.getId() + 1;

        Timestamp now = new Timestamp(System.currentTimeMillis());
        saveGameState(new GameState(largest, now, now));
        return largest;
    }

    /**
     *
     * @param state the state we wish to write to persistent storage
     */
    @Override
    public void saveGameState(GameState state)
    {
        if(state == null) throw new IllegalArgumentException("State must not be null");
        state.setCurrentTime();

        try
        {
            cmdString = "Delete from StateUpgrades where StateID=" + state.getId();
            updateCount = st1.executeUpdate(cmdString);
            checkWarning(st1, updateCount);

            cmdString = "Delete from GameStates where StateID=" + state.getId();
            updateCount = st1.executeUpdate(cmdString);
            checkWarning(st1, updateCount);

            cmdString = "Insert into GameStates Values(" + state.getId() + "," + state.getCurrency() + "," + state.getNetWorth() + ",'" + state.getCreationTime() + "','" + state.getCurrentTime() + "')";
            updateCount = st1.executeUpdate(cmdString);
            checkWarning(st1, updateCount);

            // Database stores both types of rateUpgrades in the same table, as only IDs are needed.
            for(Map.Entry<Integer, Integer> entry : state.getAllUpgradeMapping().entrySet())
            {
                cmdString = "Insert into StateUpgrades Values(" + state.getId() + "," + entry.getKey() + "," + entry.getValue() + ")";
                updateCount = st1.executeUpdate(cmdString);
                checkWarning(st1, updateCount);
            }
        }
        catch(SQLException e)
        {
            processSQLError(e);
        }
    }

    /**
     * Fills a given list with all states in persistent storage.
     * @param populate the list to fill with all states.
     */
    @Override
    public void getAllSavedStates(List<GameState> populate)
    {
        populate.clear();
        populate.addAll(queryGameStates());
    }

    public String checkWarning(Statement st, int updateCount)
    {
        String result = null;
        try
        {
            SQLWarning warning = st.getWarnings();
            if(warning != null)
                result = warning.getMessage();
        }
        catch(Exception e)
        {
            result = processSQLError(e);
        }
        if(updateCount != 1)
            result = "Tuple not inserted correctly.";

        return result;
    }

    public String processSQLError(Exception e)
    {
        String result = "*** SQL Error: " + e.getMessage();

        // Remember, this will NOT be seen by the user!
        e.printStackTrace();

        return result;
    }
}
