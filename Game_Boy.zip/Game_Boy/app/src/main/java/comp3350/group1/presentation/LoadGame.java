package comp3350.group1.presentation;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import comp3350.group1.R;
import comp3350.group1.business.AccessGameState;
import comp3350.group1.objects.GameState;

/**
 * The screen to display all of our previously saved games.
 * Can either go back to the main menu, or continue playing a saved game.
 */
public class LoadGame extends AppCompatActivity
{
    AccessGameState access;

    Dialog deleteDialog;

    /**
     * Called on creation of the activity. We do our interface functionality in here.
     * @param savedInstanceState the saved instance bundle.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_game);

        updateGameStateList();

        deleteDialog = new Dialog(this);

    }



    public void createDialogue(GameState state)
    {
        AlertDialog.Builder alertDlg = new AlertDialog.Builder(this);
        alertDlg.setMessage("Are you sure you want to delete the game?");
        alertDlg.setCancelable(false);

        alertDlg.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                access.deleteGame(state.getId());
                updateGameStateList();
            }
        });

        alertDlg.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        alertDlg.create().show();
    }


    private void showDialog(GameState gameState){

        deleteDialog.setContentView(R.layout.layout_delete_dialog);

        ((TextView)deleteDialog.findViewById(R.id.deleteTextTitle)).setText("Saved Game Delete Alert!");
        ((TextView)deleteDialog.findViewById(R.id.deleteTextMessage)).setText("Are you sure you want to delete the saved game?");
        ((Button)deleteDialog.findViewById(R.id.deletePositiveAction)).setText("Delete");
        ((Button)deleteDialog.findViewById(R.id.deleteNegativeAction)).setText("Cancel");
        ((ImageView)deleteDialog.findViewById(R.id.deleteIcon)).setImageResource(R.drawable.ic_delete);


        deleteDialog.findViewById(R.id.deletePositiveAction).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                access.deleteGame(gameState.getId());
                updateGameStateList();
                deleteDialog.dismiss();
            }
        });

        deleteDialog.findViewById(R.id.deleteNegativeAction).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteDialog.dismiss();
            }
        });

        if(deleteDialog.getWindow() != null){
            deleteDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        }

        deleteDialog.show();
    }


    /**
     * Refresh and show the list of GameStates in the load screen.
     */
    private void updateGameStateList()
    {
        // Simple list for save games in load Game Screen.
        ArrayAdapter<GameState> savedGameArrayAdapter;
        ArrayList<GameState> savedGames = new ArrayList<>();

        access = new AccessGameState();
        access.getAllSavedStates(savedGames);

        // Updates the text for the games to load
        savedGameArrayAdapter = new ArrayAdapter<GameState>(this, 0, savedGames)
        {
            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                GameState state = savedGames.get(position);
                if(convertView == null)
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.load_game_menu_item, parent, false);

                // Display values from GameState --------------------------------------------
                TextView text1 = convertView.findViewById(R.id.savedTime);
                TextView text2 = convertView.findViewById(R.id.NetWorth);
                TextView text3 = convertView.findViewById(R.id.Currency);
                TextView text4 = convertView.findViewById(R.id.PerSecond);
                TextView text5 = convertView.findViewById(R.id.GainOnClick);

                // Delete button --------------------------------------------
                Button deleteBtn = convertView.findViewById(R.id.deleteBtn);
//                deleteBtn.setOnClickListener(view ->
//                {
//                    createDialogue(state);
//                });

                deleteBtn.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        showDialog(state);
                    }
                });

                // Load button-----------------------------------------------
                Button loadBtn = convertView.findViewById(R.id.loadBtn);

                loadBtn.setOnClickListener(view ->
                {
                    // Sends the ID of the GameState we want to load to the main activity.
                    Intent intent = new Intent(LoadGame.this, MainActivity.class);
                    Bundle b = new Bundle();
                    b.putInt(GameState.STATE_ID_KEY, savedGames.get(position).getId());
                    intent.putExtras(b);
                    startActivity(intent);
                });

                text1.setText("Last Saved: " + state.getCurrentTime().toString());
                text2.setText("Net Worth: " + state.getNetWorth());
                text3.setText("Currency: " + state.getCurrency());
                text4.setText("Per Second: " + (long)state.getCurrencyPerSecond());
                text5.setText("Gain on Click: " + state.getClickBonus());
                return convertView;
            }
        };

        final ListView loadGameList = findViewById(R.id.loadGameList);
        loadGameList.setAdapter(savedGameArrayAdapter);


    }
}