package comp3350.group1.objects;

public abstract class Upgrade implements IPurchasableEffect
{
    // The upgrade ID from the database.
    private final int ID;

    // The displayed name of the upgrade.
    private final String NAME;

    // The initial cost of an upgrade.
    private final long BASE_COST;

    // How much the upgrade cost will increase by.
    private final double UPGRADE_COST_MULTIPLIER;

    // The rule defining when this upgrade can be unlocked.
    private final UnlockRule UNLOCK_RULE;

    public Upgrade(int id, String name, long baseCost, double costMultiplier, UnlockRule unlockRule)
    {
        if(id <= 0) throw new IllegalArgumentException("RateUpgrade ID must be a positive int: " + id);
        if(name == null) throw new IllegalArgumentException("RateUpgrade name must not be null");
        if(baseCost <= 0) throw new IllegalArgumentException("Base Cost must be greater than 0: " + baseCost);
        if(costMultiplier <= 1) throw new IllegalArgumentException("Cost Multiplier must be greater than 1: " + costMultiplier);

        this.ID = id;
        this.NAME = name;
        this.BASE_COST = baseCost;
        this.UPGRADE_COST_MULTIPLIER = costMultiplier;
        this.UNLOCK_RULE = unlockRule;
    }

    /**
     * @return the database ID of this upgrade
     */
    public int getId()
    {
        return ID;
    }

    /**
     * @return the type of upgrade this is
     */
    public String getName()
    {
        return NAME;
    }

    /**
     * @return the base cost of the upgrade
     */
    public long getBaseCost()
    {
        return BASE_COST;
    }

    /**
     * @return how much to multiply the base cost by when purchased
     */
    public double getCostMultiplier()
    {
        return UPGRADE_COST_MULTIPLIER;
    }

    /**
     * @param state the GameState to match the UnlockRule condition against
     * @return whether this upgrade is unlocked based on the state.
     */
    public boolean isUnlocked(GameState state)
    {
        // If there is no rule, this RateUpgrade is unlocked by default.
        if (UNLOCK_RULE == null)
            return true;
        else
            return UNLOCK_RULE.isUnlocked(state);
    }
}
