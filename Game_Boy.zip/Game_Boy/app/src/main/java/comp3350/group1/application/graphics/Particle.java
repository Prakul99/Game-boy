package comp3350.group1.application.graphics;

import org.mini2Dx.gdx.math.Vector2;

/**
 * used to hold all the information needed to render a particle
 * Also does the rendering by using a passed in spritebatch
 */
public class Particle
{
    //the effective width and height the particles are concerned about
    public static final float WORLD_WIDTH = 720;
    public static final float WORLD_HEIGHT = 1280;

    //needed for movement
    private Vector2 pos;
    private Vector2 velocity;
    private Vector2 acceleration;

    //how long it will be on screen, in seconds
    private final float INITIAL_LIFE;
    private float lifespan;

    //width & height
    private float dim;

    //texture region for this particle
    private TextureRegion tex;

    //color
    private float r,g,b,a;

    /**
     *
     * @param pos
     * @param velocity
     * @param accel
     * @param dim
     * @param lifespan
     * @param tex
     * @param r
     * @param g
     * @param b
     * @param a
     */
    public Particle(Vector2 pos, Vector2 velocity, Vector2 accel, float dim, float lifespan, TextureRegion tex,
                    float r, float g, float b, float a)
    {
        this.pos = new Vector2(pos);
        this.velocity = new Vector2(velocity);
        this.acceleration = new Vector2(accel);

        this.lifespan = INITIAL_LIFE = lifespan;
        this.dim = dim;

        this.tex = tex;
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
    }

    /**
     * Does particle logic
     * Updates positions/velocities & checks border boundaries
     *
     * @param screenDim width and height of the world
     * @param dt deltatime in seconds
     */
    public void update(Vector2 screenDim, float dt)
    {
        pos.x += velocity.x * dt;
        pos.y += velocity.y * dt;

        velocity.x += acceleration.x * dt;
        velocity.y += acceleration.y * dt;

        if(pos.x <= 0)
        {
            pos.x = 1;
            velocity.x = -velocity.x;
        }
        if(pos.x >= screenDim.x)
        {
            pos.x = screenDim.x - 1;
            velocity.x = -velocity.x;
        }
        if(pos.y <= 0)
        {
            pos.y = 1;

            velocity.y = -velocity.y * 0.5f;
        }
        if(pos.y >= screenDim.y)
        {
            pos.y = screenDim.y -= 1;
        }

        lifespan -= dt;
    }

    /**
     *
     * @return particle is alive or not
     */
    public boolean isAlive()
    {
        return lifespan >= 0;
    }

    /**
     * Adds particle to batch
     * @param s batch to add to
     */
    public void render(Spritebatch s)
    {
        if(!isAlive()) return;
        s.setColor(r, g, b, a);
        s.draw(tex, pos.x, pos.y, dim, dim);
    }
}
