package comp3350.group1.application.graphics;

import android.opengl.GLES20;

import org.mini2Dx.gdx.math.Matrix4;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Arrays;

/**
 * Used to batch textured-quad data together to send to the GPU all at once.
 *
 * has an immediate-mode API
 *
 * Example Usage:
 *
 * spriteBatch.begin(ProjectionMatrix);
 *
 * spriteBatch.draw(textureRegion, x, y, width, height);
 * spriteBatch.draw(textureRegion1, x1, y1, width1, height1);
 * .
 * .
 * .
 * spriteBatch.draw(textureRegionn, xn, yn, widthn, heightn);
 *
 * spritebatch.end();
 */
public class Spritebatch
{
    //vertex shader for textured/colored quad
    private final String vertexShaderCode =
            "attribute vec2 a_Position;" +
            "attribute vec2 a_TexCoords;" +
            "attribute vec4 a_Color;" +

            "uniform mat4 mvp;" +

            "varying vec4 color;" +
            "varying vec2 texCoords;" +

            "void main() " +
            "{" +
            "   color = a_Color;" +
            "   texCoords = vec2(a_TexCoords.x, 1.0 - a_TexCoords.y);" +
            "   gl_Position = mvp * vec4(a_Position, 0.0, 1.0);" +
            "}";

    //fragment shader for textured/colored quad
    private final String fragmentShaderCode =
            "precision highp float;" +

            "varying vec4 color;" +
            "varying vec2 texCoords;" +

            "uniform sampler2D u_Texture;" +

            "void main()" +
            " {" +
            "  gl_FragColor = color * texture2D(u_Texture, texCoords);" +
            "}";

    //number of vertices to be rendered
    private int vertexCount = 0;

    //buffer for position data
    private int positionDataIndex;
    private float[] positionData;

    //buffer for texture coordinate data
    private int texCoordDataIndex;
    private float[] texCoordData;

    //buffer for color data
    private int colorDataIndex;
    private float[] colorData;

    //number of quads than can be batched
    //we can adjust this to change memory usage
    private int MAX_QUADS = 512;

    //if the batch is currently having data added to it
    private boolean enabled;

    //currently set color
    private float r;
    private float g;
    private float b;
    private float a;

    private Matrix4 projection;

    //the texture file we are currently using
    private Texture currentTex = null;
    //id to use shader
    private int shaderID;

    /**
     *  Initializes our buffers and creates our shader
     */
    public Spritebatch()
    {
        enabled = false;
        r = g = b = a = 1;

        positionData = new float[2 * 6 * MAX_QUADS];
        texCoordData = new float[2 * 6 * MAX_QUADS];
        colorData    = new float[4 * 6 * MAX_QUADS];

        int vertShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        while((GLES20.glGetError()) != GLES20.GL_NO_ERROR)
        {
            System.out.println("ERROR COMPILING SHADER");
        }
        int fragShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);
        while((GLES20.glGetError()) != GLES20.GL_NO_ERROR)
        {
            System.out.println("ERROR COMPILING SHADER");
        }

        shaderID = GLES20.glCreateProgram();

        GLES20.glAttachShader(shaderID, vertShader);
        while((GLES20.glGetError()) != GLES20.GL_NO_ERROR)
        {
            System.out.println("ERROR COMPILING SHADER");
        }

        GLES20.glAttachShader(shaderID, fragShader);
        while((GLES20.glGetError()) != GLES20.GL_NO_ERROR)
        {
            System.out.println("ERROR COMPILING SHADER");
        }
        GLES20.glLinkProgram(shaderID);

        while((GLES20.glGetError()) != GLES20.GL_NO_ERROR)
        {
            System.out.println("ERROR COMPILING SHADER");
        }
    }

    /**
     *
     * @param proj projection matrix to apply to shader
     */
    public void begin(Matrix4 proj)
    {
        if(enabled) throw new IllegalStateException("Spritebatch.end must be called before begin");
        enabled = true;
        projection = proj.cpy();
    }

    /**
     * Changes the color to applied to spritebatch.draw
     *
     * @param r
     * @param g
     * @param b
     * @param a
     */
    public void setColor(float r, float g, float b, float a)
    {
        this.r = r;
        this.b = b;
        this.g = g;
        this.a = a;
    }

    /**
     * Adds data to buffer to we can batch to screen
     *
     * @param tex region to render
     * @param x
     * @param y
     * @param w
     * @param h
     */
    public void draw(TextureRegion tex, float x, float y, float w, float h)
    {
        if(currentTex == null)
        {
            currentTex = tex.getTexture();
        }

        //if the texture is different we make the draw call
        if(currentTex != tex.getTexture())
        {
            end();
            begin(projection);
            currentTex = tex.getTexture();
        }
        //if we hit max quads we make the draw call
        if(vertexCount / 6 >= MAX_QUADS)
        {
            end();
            begin(projection);
            currentTex = tex.getTexture();
        }

        positionData[positionDataIndex++] = x - (w / 2);
        positionData[positionDataIndex++] = y - (h / 2);
        texCoordData[texCoordDataIndex++] = tex.getX() / tex.getTexture().getWidth();
        texCoordData[texCoordDataIndex++] = tex.getY() / tex.getTexture().getHeight();
        colorData[colorDataIndex++] = r;
        colorData[colorDataIndex++] = g;
        colorData[colorDataIndex++] = b;
        colorData[colorDataIndex++] = a;

        positionData[positionDataIndex++] = x + (w / 2);
        positionData[positionDataIndex++] = y - (h / 2);
        texCoordData[texCoordDataIndex++] = (tex.getX() + tex.getWidth()) / tex.getTexture().getWidth();
        texCoordData[texCoordDataIndex++] = tex.getY() / tex.getTexture().getHeight();
        colorData[colorDataIndex++] = r;
        colorData[colorDataIndex++] = g;
        colorData[colorDataIndex++] = b;
        colorData[colorDataIndex++] = a;

        positionData[positionDataIndex++] = x + (w / 2);
        positionData[positionDataIndex++] = y + (h / 2);
        texCoordData[texCoordDataIndex++] = (tex.getX() + tex.getWidth()) / tex.getTexture().getWidth();
        texCoordData[texCoordDataIndex++] = (tex.getY() + tex.getHeight()) / tex.getTexture().getHeight();
        colorData[colorDataIndex++] = r;
        colorData[colorDataIndex++] = g;
        colorData[colorDataIndex++] = b;
        colorData[colorDataIndex++] = a;


        positionData[positionDataIndex++] = x - (w / 2);
        positionData[positionDataIndex++] = y - (h / 2);
        texCoordData[texCoordDataIndex++] = tex.getX() / tex.getTexture().getWidth();
        texCoordData[texCoordDataIndex++] = tex.getY() / tex.getTexture().getHeight();
        colorData[colorDataIndex++] = r;
        colorData[colorDataIndex++] = g;
        colorData[colorDataIndex++] = b;
        colorData[colorDataIndex++] = a;

        positionData[positionDataIndex++] = x + (w / 2);
        positionData[positionDataIndex++] = y + (h / 2);
        texCoordData[texCoordDataIndex++] = (tex.getX() + tex.getWidth()) / tex.getTexture().getWidth();
        texCoordData[texCoordDataIndex++] = (tex.getY() + tex.getHeight()) / tex.getTexture().getHeight();
        colorData[colorDataIndex++] = r;
        colorData[colorDataIndex++] = g;
        colorData[colorDataIndex++] = b;
        colorData[colorDataIndex++] = a;

        positionData[positionDataIndex++] = x - (w / 2);
        positionData[positionDataIndex++] = y + (h / 2);
        texCoordData[texCoordDataIndex++] = tex.getX() / tex.getTexture().getWidth();
        texCoordData[texCoordDataIndex++] = (tex.getY() + tex.getHeight()) / tex.getTexture().getHeight();
        colorData[colorDataIndex++] = r;
        colorData[colorDataIndex++] = g;
        colorData[colorDataIndex++] = b;
        colorData[colorDataIndex++] = a;

        vertexCount += 6;
    }

    /**
     * Flushes data to the GPU and renders
     * resets all information in the spritebatch so we can start again
     */
    public void end()
    {
        if(!enabled) throw new IllegalStateException("Spritebatch.begin must be called before end");
        enabled = false;

        if(vertexCount == 0) return;


        FloatBuffer positionBuffer;
        ByteBuffer pbb = ByteBuffer.allocateDirect(positionData.length * 4);
        pbb.order(ByteOrder.nativeOrder());
        positionBuffer = pbb.asFloatBuffer();
        positionBuffer.put(positionData);
        positionBuffer.position(0);

        FloatBuffer texCoordBuffer;
        ByteBuffer tbb = ByteBuffer.allocateDirect(texCoordData.length * 4);
        tbb.order(ByteOrder.nativeOrder());
        texCoordBuffer = tbb.asFloatBuffer();
        texCoordBuffer.put(texCoordData);
        texCoordBuffer.position(0);

        FloatBuffer colorBuffer;
        ByteBuffer cbb = ByteBuffer.allocateDirect(colorData.length * 4);
        cbb.order(ByteOrder.nativeOrder());
        colorBuffer = cbb.asFloatBuffer();
        colorBuffer.put(colorData);
        colorBuffer.position(0);


        // Add program to OpenGL ES environment
        GLES20.glUseProgram(shaderID);

        // get handle to vertex shader's vPosition member
        // Enable a handle to the triangle vertices
        // Prepare the triangle coordinate data
        int positionHandle = GLES20.glGetAttribLocation(shaderID, "a_Position");
        if(positionHandle == -1) System.out.println("Position Handle Error");
        GLES20.glEnableVertexAttribArray(positionHandle);
        GLES20.glVertexAttribPointer(positionHandle, 2,
                                    GLES20.GL_FLOAT, false,
                                    2 * 4, positionBuffer);

        int texCoordHandle = GLES20.glGetAttribLocation(shaderID, "a_TexCoords");
        if(positionHandle == -1) System.out.println("TexCoord Handle Error");
        GLES20.glEnableVertexAttribArray(texCoordHandle);
        GLES20.glVertexAttribPointer(texCoordHandle, 2,
                GLES20.GL_FLOAT, false,
                2 * 4, texCoordBuffer);

        int colorHandle = GLES20.glGetAttribLocation(shaderID, "a_Color");
        if(positionHandle == -1) System.out.println("Color Handle Error");
        GLES20.glEnableVertexAttribArray(colorHandle);
        GLES20.glVertexAttribPointer(colorHandle, 4,
                GLES20.GL_FLOAT, false,
                4 * 4, colorBuffer);


        int projectionHandle = GLES20.glGetUniformLocation(shaderID, "mvp");
        GLES20.glUniformMatrix4fv(projectionHandle, 1, false, projection.val, 0);

        int textureHandle = GLES20.glGetUniformLocation(shaderID, "u_Texture");
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, currentTex.getID());
        GLES20.glUniform1i(textureHandle, 0);


        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);

        positionDataIndex = 0;
        colorDataIndex = 0;
        texCoordDataIndex = 0;
        vertexCount = 0;
        currentTex = null;
    }

    /**
     * Helper to compile shader
     *
     * @param type
     * @param shaderCode
     * @return
     */
    private int loadShader(int type, String shaderCode)
    {
        int shader = GLES20.glCreateShader(type);

        // add the source code to the shader and compile it
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);

        return shader;
    }
}
