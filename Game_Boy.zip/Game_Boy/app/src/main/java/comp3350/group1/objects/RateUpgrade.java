package comp3350.group1.objects;

/**
 * This class holds the information about a certain upgrade
 * information will be pulled from the database and stored in memory via this class
 */
public class RateUpgrade extends Upgrade implements IPurchasableEffect
{
    // How much the upgrade will increase the lines per second.
    private final double PER_SECOND_INCREASE;

    private static final String EFFECT_DESCRIPTOR = "Currency Per Second";

    /**
     * @param id              The ID of the upgrade
     * @param name            The name of the upgrade
     * @param perSecond   How much this upgrade increases the currency per second
     * @param baseCost        The base cost of the upgrade
     * @param costMultiplier  How much to multiply the base cost when purchased
     * @param unlockRule      The rule defining when this upgrade can be unlocked
     */
    public RateUpgrade(int id, String name, double perSecond, long baseCost, double costMultiplier, UnlockRule unlockRule)
    {
        super(id, name, baseCost, costMultiplier, unlockRule);
        if(perSecond <= 0) throw new IllegalArgumentException("Per Second Increment must be greater than 0: " + perSecond);

        this.PER_SECOND_INCREASE = perSecond;
    }

    @Override
    public Type getType()
    {
        return Type.Rate;
    }

    /**
     * @return the label for the upgrade's general effect category.
     */
    @Override
    public String getEffectDescriptor()
    {
        return EFFECT_DESCRIPTOR;
    }

    /**
     * @return the magnitude of the effect granted by the upgrade.
     */
    @Override
    public double getEffectAmount()
    {
        return PER_SECOND_INCREASE;
    }

}
