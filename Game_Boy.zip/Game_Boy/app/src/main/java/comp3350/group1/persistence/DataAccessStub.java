package comp3350.group1.persistence;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import comp3350.group1.objects.GameState;
import comp3350.group1.objects.ClickUpgrade;
import comp3350.group1.objects.IPurchasableEffect;
import comp3350.group1.objects.RateUpgrade;
import comp3350.group1.objects.UnlockRule;

/**
 * This uses our API for data accessing.
 * The implementation is non-persistent, generating all data values at runtime
 */
public class DataAccessStub implements IDataAccess
{
    // List of all GameState objects stored in "DB". This represents our multiple saved states.
    private List<GameState> states;

    // List of all Upgrades.
    private List<RateUpgrade> rateUpgrades;
    // List of all manual rateUpgrades.
    private List<ClickUpgrade> clickUpgrades;

    /**
     * Initialize our data access
     */
    public void open()
    {
        rateUpgrades = new ArrayList<>();
        clickUpgrades = new ArrayList<>();

        // RateUpgrades
        rateUpgrades.add(new RateUpgrade(100, "Snack Delivery", 1, 10, 1.30, null));
        rateUpgrades.add(new RateUpgrade(101, "Free Drink", 2, 15, 1.35, new UnlockRule(0,0,0,100,5)));
        rateUpgrades.add(new RateUpgrade(102, "Catered Lunch", 3, 20, 1.40, new UnlockRule(0,0,0,101,10)));

        rateUpgrades.add(new RateUpgrade(200, "Extra Screen Space", 4, 80, 1.35, null));
        rateUpgrades.add(new RateUpgrade(201, "Fancy New IPS Panel Monitor", 6, 100, 1.40, new UnlockRule(0,0,0,200,5)));
        rateUpgrades.add(new RateUpgrade(202, "Extra Vertical Monitor", 8, 120, 1.45, new UnlockRule(0,0,0,201,10)));

        rateUpgrades.add(new RateUpgrade(300, "Mechanical Keyboard Upgrade", 9, 180, 1.40, new UnlockRule(20,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(301, "Improved Auto-Correct Technology", 12, 210, 1.45, new UnlockRule(0,0,0,300,10)));
        rateUpgrades.add(new RateUpgrade(302, "Premium Hipster Keycaps", 15, 240, 1.50, new UnlockRule(0,0,0,301,10)));

        rateUpgrades.add(new RateUpgrade(400, "Documentation Lookup", 16, 320, 1.45, new UnlockRule(200,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(401, "Miraculous StackOverflow Luck", 20, 360, 1.50, new UnlockRule(0,0,0,400,10)));
        rateUpgrades.add(new RateUpgrade(402, "High Quality Braico Lecture Notes", 24, 400, 1.55, new UnlockRule(0,0,0,401,15)));

        rateUpgrades.add(new RateUpgrade(500, "Calm, Quiet and Focused", 25, 500, 1.50, new UnlockRule(1000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(501, "Extra White Noise Machine", 30, 550, 1.55, new UnlockRule(0,0,0,500,15)));
        rateUpgrades.add(new RateUpgrade(502, "Oh my God, he has AirPods in!", 35, 600, 1.60, new UnlockRule(0,0,0,501,15)));

        rateUpgrades.add(new RateUpgrade(600, "New Hire: Junior Developer", 50, 750, 1.55, new UnlockRule(4000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(601, "New Hire: Senior Developer", 75, 1000, 1.60, new UnlockRule(0,0,0,600,15)));
        rateUpgrades.add(new RateUpgrade(602, "Promoted: Braico", 100, 1500, 1.65, new UnlockRule(0,0,0,601,15)));

        rateUpgrades.add(new RateUpgrade(700, "Server Farms", 400, 100000, 1.70, new UnlockRule(10000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(800, "Extra Processing Thread", 1600, 500000, 1.75, new UnlockRule(40000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(900, "nVIDIA Quinto-OMG CAD/CGI m15532 GPU Unit", 8000, 3000000, 1.80, new UnlockRule(100000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(1000, "Ascension to Solving P=NP", 30000, 60000000, 1.85, new UnlockRule(250000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(1100, "Research on Whether Life is a Simulation", 200000, 400000000, 1.90, new UnlockRule(500000,0,0,0,0)));
        rateUpgrades.add(new RateUpgrade(1200, "*Takes off Sunglasses*", 999999, 2147483647, 2.00, new UnlockRule(999999,0,9999999,0,0)));

        // ClickUpgrades
        clickUpgrades.add(new ClickUpgrade(1000100, "Phalange Resistance Training", 1, 80, 1.50, null));
        clickUpgrades.add(new ClickUpgrade(1000101, "Fingers of Steel", 2, 160, 1.55, new UnlockRule(0,0,0,1000100,3)));
        clickUpgrades.add(new ClickUpgrade(1000102, "Unnatural Phalangeal Stamina", 3, 240, 1.60, new UnlockRule(0,0,0,1000101,5)));

        clickUpgrades.add(new ClickUpgrade(1000200, "Upgraded Gaming Mouse", 4, 640, 1.55, new UnlockRule(0,3,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1000201, "Extra Mouse Buttons", 6, 800, 1.60, new UnlockRule(0,0,0,1000200,3)));
        clickUpgrades.add(new ClickUpgrade(1000202, "Luxury Trackpads", 8, 960, 1.65, new UnlockRule(0,0,0,1000201,5)));

        clickUpgrades.add(new ClickUpgrade(1000300, "FDA-Approved Medical Wristbands", 9, 1440, 1.60, new UnlockRule(0,10,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1000301, "Repetitive Motion Injury Treatment", 12, 1680, 1.65, new UnlockRule(0,0,0,1000300,3)));
        clickUpgrades.add(new ClickUpgrade(1000302, "Carpal Tunnel Protection", 15, 1920, 1.70, new UnlockRule(0,0,0,1000301,5)));

        clickUpgrades.add(new ClickUpgrade(1000400, "Ethical Click Macros", 16, 2560, 1.65, new UnlockRule(0,100,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1000401, "AutoHotkey Warrior", 20, 2880, 1.70, new UnlockRule(0,0,0,1000400,3)));
        clickUpgrades.add(new ClickUpgrade(1000402, "Unethical Click Macros", 24, 3200, 1.75, new UnlockRule(0,0,0,1000401,5)));

        clickUpgrades.add(new ClickUpgrade(1000500, "Army of Mice", 25, 6000, 1.70, new UnlockRule(0,350,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1000501, "Rat Kingdom", 40, 8000, 1.75, new UnlockRule(0,0,0,1000500,3)));
        clickUpgrades.add(new ClickUpgrade(1000502, "Wait, they were robots?", 60, 12000, 1.80, new UnlockRule(0,0,0,1000501,5)));

        clickUpgrades.add(new ClickUpgrade(1000700, "The Left Mouse Button is Mightier", 200, 400000, 1.75, new UnlockRule(0,800,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1000800, "One-Click Man", 800, 2000000, 1.80, new UnlockRule(0,4000,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1000900, "Click Click Revolution", 2000, 12000000, 1.85, new UnlockRule(0,10000,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1001000, "Machine Gun Jerry", 5000, 64000000, 1.90, new UnlockRule(0,22000,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1001100, "Click Power Over 9000", 12000, 480000000, 1.95, new UnlockRule(0,35000,0,0,0)));
        clickUpgrades.add(new ClickUpgrade(1001200, "The Boy Who Clicked", 69420, 2147483647, 2.00, new UnlockRule(0,69420,0,0,0)));

        states = new ArrayList<>();

        HashMap<IPurchasableEffect, Integer> upgradeMap0 = new HashMap<>();
        HashMap<IPurchasableEffect, Integer> upgradeMap1 = new HashMap<>();
        HashMap<IPurchasableEffect, Integer> upgradeMap2 = new HashMap<>();
        upgradeMap0.put(rateUpgrades.get(0), 4);

        states = new ArrayList<>();
        Timestamp startTime = Timestamp.valueOf("9999-12-31 00:00:00");
        Timestamp savedTime = Timestamp.valueOf("1999-12-31 00:00:00");

        states.add(new GameState(0, startTime, savedTime, 3000, 0, upgradeMap0));
        states.add(new GameState(1, startTime, savedTime, 3000, 0, upgradeMap1));
        states.add(new GameState(2, startTime, savedTime, 3000, 0, upgradeMap2));

        System.out.println("Opened Stub Database");
    }

    /**
     * Remove a game state from the list of saved games.
     * @param id The StateID to be deleted.
     */
    @Override
    public void deleteSaveGame(int id)
    {
        Iterator<GameState> gameStateIterator = states.iterator();
        while(gameStateIterator.hasNext())
            if(gameStateIterator.next().getId() == id)
                gameStateIterator.remove();
    }

    /**
     * Close our data access
     */
    @Override
    public void close()
    {
        System.out.println("Closed Stub Database");
    }

    /**
     * Fills a given list with all RateUpgrades in persistent storage.
     * @param result The list to fill with all RateUpgrades.
     */
    @Override
    public void getAllRateUpgrades(List<IPurchasableEffect> result)
    {
        result.clear();
        result.addAll(rateUpgrades);
    }

    /**
     * Fills a given list with all ClickUpgrades in persistent storage.
     * @param result The list to fill with all ClickUpgrades.
     */
    @Override
    public void getAllClickUpgrades(List<IPurchasableEffect> result)
    {
        result.clear();
        result.addAll(clickUpgrades);
    }

    /**
     * Creates a new GameState.
     * @return ID of the newly created GameState.
     */
    @Override
    public int createNewGameState()
    {
        int largest = 0;
        for(GameState s : states)
            if(s.getId() >= largest)
                largest = s.getId() + 1;

        Timestamp now = new Timestamp(System.currentTimeMillis());
        states.add(new GameState(largest, now, now));

        return largest;
    }

    /**
     * @param ID the ID of the GameState we want.
     * @return the GameState with given ID.
     */
    @Override
    public GameState getGameState(int ID)
    {
        if(ID < 0) throw new IllegalArgumentException("ID must not be negative: " + ID);

        GameState result = null;
        for(GameState s : states)
            if(s.getId() == ID)
                result = s;

        return result;
    }

    /**
     * @param state the state we wish to write to persistent storage
     */
    @Override
    public void saveGameState(GameState state)
    {
        deleteSaveGame(state.getId());
        state.setCurrentTime();
        states.add(state);
    }

    /**
     * Fills a given list with all states in persistent storage.
     * @param populate the list to fill with all states.
     */
    @Override
    public void getAllSavedStates(List<GameState> populate)
    {
        populate.clear();
        populate.addAll(states);
    }
}
