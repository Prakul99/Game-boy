package comp3350.group1.objects;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 *  Holds and modifies the current state of the game
 *
 *  This class is responsible for updating how much currency we have
 *  given the set of upgrades the state currently contains.
 *
 *
 *  It is also possible to modify this currency manually.
 *  for example:
 *  this is used in the case where we hit the "compile" button on screen to
 *  manually increment the currency value
 */
public class GameState
{
    static public final String STATE_ID_KEY = "state_id";
    static public final double REFUND_PERCENTAGE = 0.70;

    // Unique identifier for GameState objects; no two states will ever share an ID.
    private int id;

    // The current amount of "Lines Compiled" in the GameState.
    private double currency;
    // The total amount of currency ever owned.
    private double netWorth;

    private Map<IPurchasableEffect, Integer> upgradeQuantities;

    // The Timestamp for when the game was first started.
    private Timestamp creationTime;

    // The Timestamp for when the game was last saved. Represents the current game time.
    private Timestamp currentTime;

    public GameState(int id, Timestamp creationTime, Timestamp currentTime)
    {
        this(id, creationTime, currentTime, 0, 0, new HashMap<>());
    }

    /**
     * Initialize a GameState.
     *  @param currency the amount of currency to start the GameState with.
     * @param netWorth
     * @param upgrades the array of upgrades to start the GameState with.
     */
    public GameState(int id, Timestamp creationTime, Timestamp currentTime, long currency, long netWorth, HashMap<IPurchasableEffect, Integer> upgrades)
    {
        if(currency < 0) throw new IllegalArgumentException("Currency must be greater than or equal to 0: " + currency );
        if(creationTime == null) throw new IllegalArgumentException("StartTime cannot be null");
        if(currentTime == null) throw new IllegalArgumentException("Current Time cannot be null");
        if(id < 0) throw new IllegalArgumentException("Id must be greater than or equal to 0: " + id);
        if(upgrades == null) throw new IllegalArgumentException("Upgrades not valid ");

        this.id = id;
        this.creationTime = creationTime;
        this.currentTime = currentTime;

        this.currency = currency;
        this.netWorth = netWorth;
        upgradeQuantities = upgrades;
    }

    /**
     * Attempts to add an upgrade the GameState with a given upgrade.
     * - If we cannot afford the upgrade, the GameState will not be affected.
     * - If we can afford the upgrade, we invalidate the cached currencyPerSecond
     *   and update the amount of the upgrade type we have purchased.
     *
     * @param upgrade the upgrade we wish to apply to the GameState.
     * @return true if we can afford the upgrade. False if the upgrade cannot be afforded.
     */
    public boolean buyUpgrade(IPurchasableEffect upgrade)
    {
        boolean result = false;
        double cost = getUpgradeCost(upgrade);

        // We have purchased this upgrade previously
        if(upgradeQuantities.containsKey(upgrade))
        {
            if(currency >= cost)
            {
                currency -= cost;
                Integer value = upgradeQuantities.get(upgrade);

                value += 1;
                upgradeQuantities.put(upgrade, value);
                result = true;
            }
        }
        else
        {
            if(currency >= cost)
            {
                currency -= cost;
                upgradeQuantities.put(upgrade, 1);

                result = true;
            }
        }

        return result;
    }

    /**
     * Resell a purchased upgrade for a certain percentage of its original value.
     *
     * @param upgrade the upgrade we wish to decrease the quantity of.
     * @return true if the result is sold. False if there is nothing to sell.
     */
    public boolean sellUpgrades(IPurchasableEffect upgrade)
    {
        boolean result = false;
        double cost = getUpgradeCost(upgrade);

        // We have purchased this upgrade previously
        if(upgradeQuantities.containsKey(upgrade))
        {
            int value = upgradeQuantities.get(upgrade);
            if(value > 0)
            {
                currency += Math.ceil(cost * REFUND_PERCENTAGE);
                value -= 1;
                upgradeQuantities.put(upgrade, value);
                result = true;
            }
        }
        return result;
    }

    /**
     * @param upgrade the upgrade being checked.
     * @return the number of times a given upgrade has been purchased.
     */
    public int getUpgradeQuantity(IPurchasableEffect upgrade)
    {
        int result = 0;
        if(upgradeQuantities.containsKey(upgrade))
            result = upgradeQuantities.get(upgrade);
        return result;
    }

    /**
     * @param upgradeId the ID of the Upgrade being checked.
     * @return the number of times the corresponding Upgrade has been purchased.
     */
    public int getUpgradeQuantity(int upgradeId)
    {
        int result = 0;
        for(Map.Entry<IPurchasableEffect, Integer> entry : upgradeQuantities.entrySet())
            if(entry.getKey().getId() == upgradeId)
                result = entry.getValue();
        return result;
    }

    /**
     * Calculates the current currency we generate per second.
     * Currency per second is dependent on the upgrades we have purchased.
     *
     * @return the currency per second the GameState will accumulate.
     */
    public double getCurrencyPerSecond()
    {
        double currencyPerSecond = 0;

        for(Map.Entry<IPurchasableEffect, Integer> entry : upgradeQuantities.entrySet())
            if(entry.getKey().getType() == IPurchasableEffect.Type.Rate)
                currencyPerSecond += entry.getKey().getEffectAmount() * entry.getValue();

        return currencyPerSecond;
    }

    /**
     * Calculate the amount of currency gained when Code Boy is clicked.
     * @return the currency gained on click.
     */
    public int getClickBonus()
    {
        int clickBonus = 1;

        for(Map.Entry<IPurchasableEffect, Integer> entry : upgradeQuantities.entrySet())
            if(entry.getKey().getType() == IPurchasableEffect.Type.Click)
                clickBonus += entry.getKey().getEffectAmount() * entry.getValue();

        return clickBonus;
    }

    /**
     * Determines the cost of an upgrade for this particular GameState.
     *
     * @param upgrade The upgrade we wish to check the cost of
     * @return how much the upgrade will cost to purchase
     */
    public long getUpgradeCost(IPurchasableEffect upgrade)
    {
        long result = upgrade.getBaseCost();
        if(upgradeQuantities.containsKey(upgrade))
            for (int i = 0; i < upgradeQuantities.get(upgrade); i++)
                result *= upgrade.getCostMultiplier();

        return result;
    }

    /**
     * @return a mapping of upgrade IDs to their quantity for saving to the database.
     */
    public HashMap<Integer, Integer> getAllUpgradeMapping()
    {
        HashMap<Integer, Integer> idMapping = new HashMap<>();

        for(Map.Entry<IPurchasableEffect, Integer> entry : upgradeQuantities.entrySet())
            idMapping.put(entry.getKey().getId(), entry.getValue());

        return idMapping;
    }

    /**
     * Allows manual increasing of currency in the GameState.
     * @param amount The amount to increase the currency by.
     */
    public void incrementCurrency(int amount)
    {
        if(amount <= 0) throw new IllegalArgumentException("Amount must be greater than 0: " + amount);
        currency += amount;
        netWorth += amount;
    }

    /**
     * @return the current currency in the GameState.
     */
    public long getCurrency()
    {
        // Storing as a double and casting as a long is intentional.
        // It is possible to earn partial currency, but when checking how much we have.
        // We want to return floor(currency) so truncating is okay.
        return (long)currency;
    }

    /**
     * @return the total amount of currency ever gained in the GameState
     */
    public long getNetWorth()
    {
        return (long)netWorth;
    }

    /**
     * Updates the GameState from a given time step.
     * This will increase the amount of currency currently stored in the GameState
     *
     * @param dt the amount of seconds to update the GameState by.
     */
    public void update(double dt)
    {
        if(dt <= 0) throw new IllegalArgumentException("delta time must be greater than 0: " + dt);
        currency += getCurrencyPerSecond() * dt;
    }

    /**
     * @return the unique identifier for this gamestate
     */
    public int getId()
    {
        return id;
    }

    /**
     * @return the time last saved time of the game.
     */
    public Timestamp getCurrentTime()
    {
        return currentTime;
    }

    /**
     * Set the time of the GameState. Called upon saving.
     */
    public void setCurrentTime()
    {
        currentTime = new Timestamp(System.currentTimeMillis());
    }

    /**
     * @return the time when the game was created
     */
    public Timestamp getCreationTime()
    {
        return creationTime;
    }

    /**
     * @return total time played by the player
     */
    public String totalTimePlayed()
    {
        long diff = currentTime.getTime() - creationTime.getTime();

        if(diff < 0)
            diff = 0;

        // Converting the time diff to Days, Hours, Minutes, Seconds
        long days = TimeUnit.MILLISECONDS.toDays(diff);
        diff -= TimeUnit.DAYS.toMillis(days);
        long hours = TimeUnit.MILLISECONDS.toHours(diff);
        diff -= TimeUnit.HOURS.toMillis(hours);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
        diff -= TimeUnit.MINUTES.toMillis(minutes);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(diff);

        if(days > 0)
            return days + " days, " + hours + " hours, " + minutes + " minutes, " + seconds + " seconds";
        if(hours > 0)
            return hours + " hours, " + minutes + " minutes, " + seconds + " seconds";
        if(minutes > 0)
            return minutes + " minutes, " + seconds + " seconds";
        return seconds + " seconds";
    }
}
