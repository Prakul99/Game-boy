package comp3350.group1.presentation;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

import comp3350.group1.R;
import comp3350.group1.business.AccessGameState;
import comp3350.group1.objects.GameState;

public class LeaderBoard extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader_board);

        updateGameStateList();
    }

    private void updateGameStateList()
    {
        // Simple list for save games in load Game Screen.
        ArrayAdapter<GameState> savedGameArrayAdapter;
        ArrayList<GameState> savedGames = new ArrayList<>();
        AccessGameState access = new AccessGameState();

        access.getAllSavedStates(savedGames);

        // Sorting the List based on the currency. The negation is intentional to reverse the order
        Collections.sort(savedGames, (lhs, rhs) -> -Long.compare(lhs.getNetWorth(), rhs.getNetWorth()));

        // Updates the text for the games to load.
        savedGameArrayAdapter = new ArrayAdapter<GameState>(this, 0, savedGames)
        {
            int rank = 1;

            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                GameState state = savedGames.get(position);

                if(convertView == null)
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.leader_board_menu_item, parent, false);

                // Display values from GameState --------------------------------------------
                TextView text1 = convertView.findViewById(R.id.Currency);
                TextView text2 = convertView.findViewById(R.id.savedTime);
                TextView text3 = convertView.findViewById(R.id.Rank);

                text1.setText("Net Worth: "+ state.getNetWorth() );
                text2.setText("Play Time: " + state.totalTimePlayed());
                text3.setText(rank + "");
                rank++;

                return convertView;
            }
        };

        final ListView loadGameList = findViewById(R.id.players_info);
        loadGameList.setAdapter(savedGameArrayAdapter);
    }

}
