package comp3350.group1.presentation;

import android.content.Context;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

import es.dmoral.toasty.Toasty;

public class ToastyHelper
{
    enum Type
    {
        WARNING,
        INFO,
        ERROR,
        SUCCESS,
    }

    public void showToasty(Context c, Type type, String message, int durationMillis)
    {
        Toast t;
        switch (type)
        {
            case WARNING:
                 t = Toasty.warning(c, message, Toast.LENGTH_SHORT);
                break;
            case INFO:
                t = Toasty.info(c, message, Toast.LENGTH_SHORT);
                break;
            case ERROR:
                t = Toasty.error(c, message, Toast.LENGTH_SHORT);
                break;
            case SUCCESS:
                t = Toasty.success(c, message, Toast.LENGTH_SHORT);
                break;
            default:
                t = null;
                break;
        }


        t.show();

        new Timer().schedule(new TimerTask()
         {
            @Override
            public void run()
            {
                t.cancel();
            }
        },
        durationMillis);
    }
}
