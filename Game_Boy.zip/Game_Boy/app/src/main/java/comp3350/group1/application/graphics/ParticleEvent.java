package comp3350.group1.application.graphics;

/**
 * The data the renderer needs to create a particle
 */
public class ParticleEvent
{
    public enum Type
    {
        Buy,
        Sell,
        Compile,
    };

    protected Type eventType;
    protected float x;
    protected float y;

    /**
     *
     * @param type
     * @param x
     * @param y
     */
    public ParticleEvent(Type type, float x, float y)
    {
        this.eventType = type;
        this.x = x;
        this.y = y;
    }
}


