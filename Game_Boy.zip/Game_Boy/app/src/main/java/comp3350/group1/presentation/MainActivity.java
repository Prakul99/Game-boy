package comp3350.group1.presentation;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import comp3350.group1.R;
import comp3350.group1.application.graphics.CustomGLSurfaceView;
import comp3350.group1.application.graphics.ParticleEvent;
import comp3350.group1.business.AccessGameState;
import comp3350.group1.business.AccessUpgrades;
import comp3350.group1.business.GameStateAutoSaver;
import comp3350.group1.business.GameStateUpdater;
import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;

/**
 * This activity is where gameplay occurs.
 */
public class MainActivity extends AppCompatActivity
{
    private AccessUpgrades upgradesAccess;
    private AccessGameState gameStateAccess;

    private GameStateUpdater gameUpdater;
    private GameStateAutoSaver autoSaver;

    private CustomGLSurfaceView glView;

    // Used to update the currency information on screen.
    private TextView currencyView;
    private TextView perSecondView;

    private Timer onScreenValueUpdater;

    private ArrayAdapter<IPurchasableEffect> upgradeAdapter;

    public enum SoundType
    {
        Buy,
        Sell,
        Click,
    }

    private boolean showUpgradeNotification;

    boolean muted;
    boolean showEffects;
    SoundPool soundPool;
    MediaPlayer music;
    HashMap<SoundType, Integer> soundEffectMap;


    //how long toast appears, in milliseconds
    private final int TOAST_TIME = 800;

    int previousRateUnlockListSize;
    int previousClickUnlockListSize;
    private IPurchasableEffect.Type currentUpgradeType = IPurchasableEffect.Type.Rate;

    /**
     * Called on activity creation.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        soundEffectMap = new HashMap<>();
        muted = false;
        showEffects = true;
        showUpgradeNotification = true;


        music = MediaPlayer.create(this, R.raw.soundtrack);
        music.start();
        music.setLooping(true);

        soundPool = new SoundPool(3, ((AudioManager)getSystemService(AUDIO_SERVICE)).STREAM_MUSIC, 1);
        soundEffectMap.put(SoundType.Buy, soundPool.load(this, R.raw.buy, 1));
        soundEffectMap.put(SoundType.Sell, soundPool.load(this, R.raw.sell, 1));
        soundEffectMap.put(SoundType.Click, soundPool.load(this, R.raw.click, 1));

        upgradesAccess = new AccessUpgrades();
        gameStateAccess = new AccessGameState();

        Bundle b = getIntent().getExtras();
        GameState state = gameStateAccess.getGameState(b.getInt(GameState.STATE_ID_KEY));

        gameUpdater = new GameStateUpdater(state);
        gameUpdater.startUpdating();

        setContentView(R.layout.activity_main);
        currencyView = findViewById(R.id.CurrencyText);
        perSecondView = findViewById(R.id.PerSecondText);
        glView = findViewById(R.id.customGLSurfaceView);

        autoSaver = new GameStateAutoSaver(true, gameUpdater.getGameState());

        // Set up the settings menu and auto-save.
        FloatingActionButton fab = findViewById(R.id.settingsActionBtn);
        PopupMenu menu = new PopupMenu(MainActivity.this, fab);
        menu.inflate(R.menu.menu_settings);
        menu.getMenu().findItem(R.id.autoSaveItem).setChecked(autoSaver.isEnabled());
        menu.getMenu().findItem(R.id.showEffectItem).setChecked(showEffects=true);
        menu.getMenu().findItem(R.id.unlockNotificationItem).setChecked(showUpgradeNotification = true);
        fab.setOnClickListener(view -> setSettingsFabMenu(menu));

        // Set up the primary Code Boy click button.
        ImageButton compileButton = findViewById(R.id.CompileButton);
        compileButton.setOnClickListener(view -> {
            playSound(SoundType.Click);
            gameUpdater.addCurrencyOnClick();
            if(showEffects) {
                glView.sendParticleEvent(new ParticleEvent(ParticleEvent.Type.Compile, view.getX() + view.getWidth() / 2, view.getY() + view.getHeight() / 2));
            }
        });
        // Set up the stored lists of upgrades.
        final List<IPurchasableEffect> upgrades = new ArrayList<>();

        upgradesAccess.getUnlockedClickUpgrades(upgrades, gameUpdater.getGameState());
        previousClickUnlockListSize = upgrades.size();

        upgradesAccess.getUnlockedRateUpgrades(upgrades, gameUpdater.getGameState());
        upgradeAdapter = createArrayAdapter(upgrades);

        previousRateUnlockListSize = upgradeAdapter.getCount();
        ListView listView = findViewById(R.id.upgradeListView);
        listView.setAdapter(upgradeAdapter);



        createValueUpdateTimer();
    }

    private void createValueUpdateTimer()
    {
        final long UPDATE_TIME_MILLIS = 16;
        // Set up screen refreshes on regular intervals.
        onScreenValueUpdater = new Timer();
        onScreenValueUpdater.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                updateView();
            }
        },
        UPDATE_TIME_MILLIS,
        UPDATE_TIME_MILLIS);
    }

    private void updateView()
    {
        runOnUiThread(() -> {

            currencyView.setText("Currency: " + gameUpdater.getCurrentCurrency());
            perSecondView.setText("Per Second: " + gameUpdater.getCurrencyPerSecond() + "\nGain On Click: " + gameUpdater.getTotalClickBonus());

            if(autoSaver.hasSavedSinceLastCheck())
                new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Game has auto-saved successfully!", TOAST_TIME);
        });
    }
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
        gameUpdater.stopUpdating();

        if(autoSaver.isEnabled())
            autoSaver.disable();

        music.stop();
        music.release();
        soundPool.release();

        onScreenValueUpdater.cancel();
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();

        startActivity(new Intent(this, FirstScreen.class));
        finish();
    }

    @Override
    protected void onResume()
    {
        music.start();
        glView.onResume();
        super.onResume();
    }

    @Override
    protected void onPause()
    {
        music.pause();
        glView.onPause();
        super.onPause();
    }

    /**
     * Set up the floating action button used to show the settings menu.
     */
    private void setSettingsFabMenu(PopupMenu menu)
    {

        menu.setOnMenuItemClickListener(menuItem -> {
            if(menuItem.getItemId() == R.id.MainMenuItem)
            {
                Intent intent = new Intent(this, FirstScreen.class);
                startActivity(intent);
            }
            if(menuItem.getItemId() == R.id.manualSaveItem)
            {
                gameStateAccess.saveGame(gameUpdater.getGameState());
                new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Game has saved successfully!", TOAST_TIME);
            }
            if(menuItem.getItemId() == R.id.muteItem)
            {
                if (menuItem.isChecked())
                {
                    menuItem.setChecked(false);
                    music.start();
                    music.setLooping(true);
                    new ToastyHelper().showToasty(this, ToastyHelper.Type.WARNING, "Music Unmuted!", TOAST_TIME);
                }
                else
                {
                    menuItem.setChecked(true);
                    music.pause();
                    new ToastyHelper().showToasty(this, ToastyHelper.Type.WARNING, "Music Muted!", TOAST_TIME);
                }
            }
            if(menuItem.getItemId() == R.id.muteEffectItem)
            {
                if (menuItem.isChecked())
                {
                    menuItem.setChecked(false);
                    muted = false;

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.WARNING, "Sound Effects Unmuted!", TOAST_TIME);
                }
                else
                    {
                    menuItem.setChecked(true);
                    muted = true;

                        new ToastyHelper().showToasty(this, ToastyHelper.Type.WARNING, "Sound Effects Muted!", TOAST_TIME);

                }
            }
            if(menuItem.getItemId() == R.id.unlockNotificationItem)
            {
                if(menuItem.isChecked())
                {
                    menuItem.setChecked(false);
                    showUpgradeNotification = false;

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Upgrade Notifications Disabled!", TOAST_TIME);
                }
                else
                {
                    menuItem.setChecked(true);
                    showUpgradeNotification = true;

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Upgrade Notifications Enabled!", TOAST_TIME);
                }
            }
            if(menuItem.getItemId() == R.id.showEffectItem)
            {
                if(menuItem.isChecked())
                {
                    menuItem.setChecked(false);
                    showEffects = false;

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Visual Effects Disabled!", TOAST_TIME);
                }
                else
                {
                    menuItem.setChecked(true);
                    showEffects = true;

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Visual Effects Enabled!", TOAST_TIME);
                }
            }
            if(menuItem.getItemId() == R.id.autoSaveItem)
            {
                if(menuItem.isChecked())
                {
                    menuItem.setChecked(false);
                    autoSaver.disable();

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Autosaving Disabled!", TOAST_TIME);
                }
                else
                {
                    menuItem.setChecked(true);
                    autoSaver.enable();

                    new ToastyHelper().showToasty(this, ToastyHelper.Type.INFO, "Autosaving Enabled!", TOAST_TIME);
                }
            }

            return true;
        });

        menu.show();
    }

    /**
     * Set the upgrades list to show RateUpgrades.
     */
    public void toggleRateUpgrades(View view)
    {
        currentUpgradeType = IPurchasableEffect.Type.Rate;
        updateUpgradesList();
    }

    /**
     * Set the upgrades list to show ClickUpgrades.
     */
    public void toggleClickUpgrades(View view)
    {
        currentUpgradeType = IPurchasableEffect.Type.Click;
        updateUpgradesList();
    }

    /**
     * Refresh the contents of the upgrades list.
     */
    private void updateUpgradesList()
    {
        ArrayList<IPurchasableEffect> upgrades = new ArrayList<>();
        if(currentUpgradeType == IPurchasableEffect.Type.Click)
        {
            upgradesAccess.getUnlockedClickUpgrades(upgrades, gameUpdater.getGameState());
            //has all the upgrades we have unlocked

            //if the sizes are different we have unlocked an upgrade
            if(previousClickUnlockListSize < upgrades.size())
            {
                previousClickUnlockListSize = upgrades.size();
                for (int i = 0; i < upgradeAdapter.getCount(); i++)
                    upgrades.remove(upgradeAdapter.getItem(i));

                if(showUpgradeNotification)
                    showUnlockDialog(upgrades.get(0));

                new AccessUpgrades().getUnlockedClickUpgrades(upgrades, gameUpdater.getGameState());
            }
        }
        else if(currentUpgradeType == IPurchasableEffect.Type.Rate)
        {
            upgradesAccess.getUnlockedRateUpgrades(upgrades, gameUpdater.getGameState());

            //if the sizes are different we have unlocked an upgrade
            if(previousRateUnlockListSize < upgrades.size())
            {
                previousRateUnlockListSize = upgrades.size();
                for (int i = 0; i < upgradeAdapter.getCount(); i++)
                    upgrades.remove(upgradeAdapter.getItem(i));

                if(showUpgradeNotification)
                    showUnlockDialog(upgrades.get(0));

                new AccessUpgrades().getUnlockedRateUpgrades(upgrades, gameUpdater.getGameState());
            }
        }

        upgradeAdapter.clear();
        upgradeAdapter.addAll(upgrades);
        upgradeAdapter.notifyDataSetChanged();
    }

    private ArrayAdapter<IPurchasableEffect> createArrayAdapter(List<IPurchasableEffect> upgradesList)
    {
        return new ArrayAdapter<IPurchasableEffect>(this, 0, upgradesList)
        {

            @Override
            public View getView(int position, View convertView, ViewGroup parent)
            {
                IPurchasableEffect upgrade = upgradesList.get(position);
                if(convertView == null)
                    convertView = LayoutInflater.from(getContext()).inflate(R.layout.upgrades_list, parent, false);

                int color = Color.parseColor("#000000");

                convertView.setBackgroundColor(color);

                TextView nameQuantityText = convertView.findViewById(R.id.UpgradeNameQuantityView);
                TextView costText = convertView.findViewById(R.id.UpgradeCostView);
                TextView effectText = convertView.findViewById(R.id.UpgradeDetailView);

                setUpgradeListText(upgrade, nameQuantityText, costText, effectText);

                Button buyButton = convertView.findViewById(R.id.buyBtn);
                buyButton.setOnClickListener(view -> setBuyListener(upgrade, nameQuantityText, costText, buyButton));

                Button sellButton = convertView.findViewById(R.id.sellBtn);
                sellButton.setOnClickListener(view -> setSellListener(upgrade, nameQuantityText, costText, sellButton));

                Button infoButton = (Button) convertView.findViewById(R.id.upgradeInfoBtn);

                infoButton.setOnClickListener(view -> showInfoDialog(upgrade));

                return convertView;
            }
        };
    }

    private void setUpgradeListText(IPurchasableEffect upgrade, TextView nameQuantityText, TextView costText, TextView effectText)
    {
        nameQuantityText.setText(upgrade.getName() + " (" + gameUpdater.getUpgradeQuantity(upgrade) + ")");
        costText.setText("Cost: " + gameUpdater.getUpgradeCost(upgrade));
        effectText.setText(upgrade.getEffectDescriptor() + " +" + (int)upgrade.getEffectAmount());
    }

    private void setBuyListener(IPurchasableEffect upgrade, TextView nameQuantityText, TextView costText, View view)
    {
        boolean success = gameUpdater.addUpgrade(upgrade);
        if(success)
        {
            int locations[] = new int[2];
            view.getLocationOnScreen(locations);
            locations[0] += view.getWidth() / 2;
            locations[1] += view.getHeight() / 2;
            if(showEffects)
                glView.sendParticleEvent(new ParticleEvent(ParticleEvent.Type.Buy, locations[0], locations[1]));

            playSound(MainActivity.SoundType.Buy);
            nameQuantityText.setText(upgrade.getName() + " (" + gameUpdater.getUpgradeQuantity(upgrade) + ")");
            costText.setText("Cost: " + gameUpdater.getUpgradeCost(upgrade));

            updateUpgradesList();

            new ToastyHelper().showToasty(this, ToastyHelper.Type.SUCCESS, "Upgrade Successful!", TOAST_TIME);
        }
        else
            new ToastyHelper().showToasty(this, ToastyHelper.Type.ERROR, "Insufficient currency to buy this Upgrade!", TOAST_TIME);
    }

    private void setSellListener(IPurchasableEffect upgrade, TextView nameQuantityText, TextView costText, View view)
    {
        boolean success = gameUpdater.sellUpgrade(upgrade);
        if(success)
        {
            int locations[] = new int[2];
            view.getLocationOnScreen(locations);
            locations[0] += view.getWidth() / 2;
            locations[1] += view.getHeight() / 2;
            if(showEffects)
                glView.sendParticleEvent(new ParticleEvent(ParticleEvent.Type.Sell, locations[0], locations[1]));

            playSound(MainActivity.SoundType.Sell);
            nameQuantityText.setText(upgrade.getName() + " (" + gameUpdater.getUpgradeQuantity(upgrade) + ")");
            costText.setText("Cost: " + gameUpdater.getUpgradeCost(upgrade));

            new ToastyHelper().showToasty(this, ToastyHelper.Type.SUCCESS, "Upgrade Sold!", TOAST_TIME);
        }
        else
            new ToastyHelper().showToasty(this, ToastyHelper.Type.ERROR, "You do not own any of these upgrades!", TOAST_TIME);
    }

    private void showUnlockDialog(IPurchasableEffect upgrade)
    {
        Dialog unlockDialog = new Dialog(this);

        unlockDialog.setContentView(R.layout.layout_success_dialog);
        ((TextView)unlockDialog.findViewById(R.id.textTitle)).setText("Congratulations!");
        ((TextView)unlockDialog.findViewById(R.id.textMessage)).setText("Unlocked " + upgrade.getEffectDescriptor() + ": " + upgrade.getName() );
        ((Button)unlockDialog.findViewById(R.id.buttonAction)).setText("Dismiss");
        ((ImageView)unlockDialog.findViewById(R.id.infoIcon)).setImageResource(R.drawable.ic_new_upgrade);

        unlockDialog.findViewById(R.id.buttonAction).setOnClickListener(view -> unlockDialog.dismiss());
        if(unlockDialog.getWindow() != null)
            unlockDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        unlockDialog.show();
    }

    private void showInfoDialog(IPurchasableEffect upgrade)
    {
        Dialog infoDialog = new Dialog(this);

        infoDialog.setContentView(R.layout.layout_success_dialog);
        int currentCost = (int)((Math.pow(upgrade.getCostMultiplier(),(gameUpdater.getUpgradeQuantity(upgrade))))*upgrade.getBaseCost());
        int nextUpdatedCost = (int)((Math.pow(upgrade.getCostMultiplier(),(gameUpdater.getUpgradeQuantity(upgrade)+1)))*upgrade.getBaseCost());
        ((TextView)infoDialog.findViewById(R.id.textTitle)).setText("Upgrade Info");
        ((TextView)infoDialog.findViewById(R.id.textMessage)).setText("Name: " + upgrade.getName() + "\nCost: " + currentCost
                + "\n" + upgrade.getEffectDescriptor() + ": " + (int)upgrade.getEffectAmount()
                + "\nNext Upgrade Cost: " + nextUpdatedCost);
        ((Button)infoDialog.findViewById(R.id.buttonAction)).setText("Dismiss");
        ((ImageView)infoDialog.findViewById(R.id.infoIcon)).setImageResource(R.drawable.ic_info);

        infoDialog.findViewById(R.id.buttonAction).setOnClickListener(view -> infoDialog.dismiss());
        if(infoDialog.getWindow() != null)
            infoDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

        infoDialog.show();
    }

    public void playSound(SoundType type)
    {
        if(!muted)
            if(soundEffectMap.containsKey(type))
                soundPool.play(soundEffectMap.get(type), 1, 1, 0, 0, 1);
    }
}
