package comp3350.group1.objects;

public interface IPurchasableEffect
{
    enum Type
    {
        Rate,
        Click,
    }

    /**
     * @return the database ID of this upgrade.
     */
    int getId();

    /**
     * @return the purchasable type identifier of this upgrade.
     */
    Type getType();

    /**
     * @return the type of upgrade this is.
     */
    String getName();

    /**
     * @return the base cost of the upgrade.
     */
    long getBaseCost();

    /**
     * @return how much to multiply the base cost by when purchased.
     */
    double getCostMultiplier();

    /**
     * @param state the GameState to match the UnlockRule condition against
     * @return whether this upgrade is unlocked based on the state.
     */
    boolean isUnlocked(GameState state);

    /**
     * @return the label for the upgrade's general effect category.
     */
    String getEffectDescriptor();

    /**
     * @return the magnitude of the effect granted by the upgrade.
     */
    double getEffectAmount();
}
