package comp3350.group1.objects;

/**
 * This class represents the information about a manual click upgrade.
 * These kinds of upgrades influence the amount of currency gained on each click of Code Boy.
 */
public class ClickUpgrade extends Upgrade implements IPurchasableEffect
{
    private final double CLICK_BONUS;

    private static final String EFFECT_DESCRIPTOR = "Click Bonus";

    /**
     * @param id              The ID of the upgrade
     * @param name            The name of the upgrade
     * @param clickBonus      How much this upgrade increases the currency gained per click
     * @param baseCost        The base cost of the upgrade
     * @param costMultiplier  How much to multiply the base cost when purchased
     * @param unlockRule      The rule defining when this upgrade can be unlocked
     */
    public ClickUpgrade(int id, String name, double clickBonus, long baseCost, double costMultiplier, UnlockRule unlockRule)
    {
        super(id, name, baseCost, costMultiplier, unlockRule);
        if(clickBonus <= 0) throw new IllegalArgumentException("Click bonus must be greater than 0: " + clickBonus);

        this.CLICK_BONUS = clickBonus;
    }

    @Override
    public Type getType()
    {
        return Type.Click;
    }

    /**
     * @return the label for the upgrade's general effect category.
     */
    @Override
    public String getEffectDescriptor()
    {
        return EFFECT_DESCRIPTOR;
    }

    /**
     * @return the magnitude of the effect granted by the upgrade.
     */
    @Override
    public double getEffectAmount()
    {
        return CLICK_BONUS;
    }
}
