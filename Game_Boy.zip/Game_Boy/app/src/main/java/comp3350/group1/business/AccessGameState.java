package comp3350.group1.business;

import java.util.List;

import comp3350.group1.application.Services;
import comp3350.group1.objects.GameState;
import comp3350.group1.persistence.IDataAccess;

/**
 * This class is used to access a GameState instance and modify it.
 */
public class AccessGameState
{
    // Accesses our persistent storage.
    private IDataAccess data;

    /**
     * Initializes our access for GameState.
     */
    public AccessGameState()
    {
        data = Services.getDataAccess();
    }

    /**
     * Creates a new GameState and returns the ID of the new state.
     * @return ID of the new GameState.
     */
    public int createNewGameState()
    {
        return data.createNewGameState();
    }

    /**
     * Writes the current GameState to persistent storage
     */
    public void saveGame(GameState state)
    {
        data.saveGameState(state);
    }

    /**
     * Remove the GameState with the specified ID.
     */
    public void deleteGame(int id)
    {
        data.deleteSaveGame(id);
    }

    /**
     * Fills a given list with all GameStates in persistent storage.
     * @param states the list to fill with GameState objects.
     */
    public void getAllSavedStates(List<GameState> states)
    {
        data.getAllSavedStates(states);
    }

    /**
     * @param ID the ID of the GameState to get.
     * @return the the GameState object corresponding to the given ID.
     */
    public GameState getGameState(int ID)
    {
        return data.getGameState(ID);
    }
}

