package comp3350.group1.application.graphics;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;



/**
 * This class is used to manage and draw all elements in the background
 *
 * This will have no real impact on gameplay, just to add some visual flair
 */
public class CustomGLSurfaceView extends GLSurfaceView
{

    private GLRenderer renderer;

    /**
     *
     *
     * @param context
     * @param attrs
     */
    public CustomGLSurfaceView(Context context, AttributeSet attrs)
    {
        super(context, attrs);

        // Create an OpenGL ES 2.0 context
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        // Set the Renderer for drawing on the GLSurfaceView
        setRenderer(renderer = new GLRenderer(context));

        getHolder().setFormat(PixelFormat.TRANSLUCENT);

        // Have to do this or else
        // GlSurfaceView wont be transparent.
        setZOrderOnTop(true);
    }

    /**
     * Passes a particle event to the renderer
     *
     * @param event the details needed to render particles
     */
    public void sendParticleEvent(ParticleEvent event)
    {
        renderer.onParticleEvent(event);
    }
}
