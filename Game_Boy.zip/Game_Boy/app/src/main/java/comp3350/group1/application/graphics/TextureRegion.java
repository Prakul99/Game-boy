package comp3350.group1.application.graphics;

/**
 * Holds a texture alongside a rectangle
 * we use this to render a portion of a texture, so we do not need to make texture switches to GPU
 */
public class TextureRegion
{

    private Texture texture;

    private int regionX;
    private int regionY;
    private int regionW;
    private int regionH;

    /**
     * Creates a textureRegion from texture
     * Assumes the region is the entire texture by default
     *
     * @param tex Texture to use
     */
    public TextureRegion(Texture tex)
    {
        this(tex, 0, 0, tex.getWidth(), tex.getHeight());
    }

    /**
     * Creates a textureRegion from texture
     * We pass in the desired bounding box as well
     *
     * @param tex Texture to use
     * @param x
     * @param y
     * @param w
     * @param h
     */
    public TextureRegion(Texture tex, int x, int y, int w, int h)
    {
        this.texture = tex;
        this.regionX = x;
        this.regionY = y;
        this.regionW = w;
        this.regionH = h;
    }

    public Texture getTexture()
    {
        return texture;
    }

    public float getX()
    {
        return regionX;
    }

    public float getY()
    {
        return regionY;
    }

    public float getWidth()
    {
        return regionW;
    }

    public float getHeight()
    {
        return regionH;
    }
}
