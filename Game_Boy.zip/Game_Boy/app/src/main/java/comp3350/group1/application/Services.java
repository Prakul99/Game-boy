package comp3350.group1.application;

import comp3350.group1.persistence.DataAccessObject;
import comp3350.group1.persistence.DataAccessStub;
import comp3350.group1.persistence.IDataAccess;

/**
 * Used to create our database access
 */
public class Services
{
    public enum DataStorage
    {
        Database,
        Stub,
    }

    private static IDataAccess dataAccessService = null;
    public static final String dbName = "SC";
    private static String dbPathName = "database/SC";

    /**
     * Initializes our access to get persistent data
     *
     * @return Interface to access our persistent data
     */
    public static IDataAccess createDataAccess(DataStorage type)
    {
        if(type == null) throw new IllegalArgumentException("Data access type cannot be null");

        if(dataAccessService == null)
        {
            if(type == DataStorage.Database)
                dataAccessService = (IDataAccess) new DataAccessObject(getDBPathName());
            else if(type == DataStorage.Stub)
                dataAccessService = new DataAccessStub();

            dataAccessService.open();
        }
        return dataAccessService;
    }

    /**
     * @return Interface to access our persistent data.
     */
    public static IDataAccess getDataAccess()
    {
        if(dataAccessService == null)
        {
            System.out.println("Connection to data access has not been established.");
            System.exit(1);
        }
        return dataAccessService;
    }

    /**
     * Safely terminates our data access.
     */
    public static void closeDataAccess()
    {
        if(dataAccessService != null)
            dataAccessService.close();

        dataAccessService = null;
    }

    private static String getDBPathName()
    {
        if(dbPathName == null)
            return dbName;
        else
            return dbPathName;
    }

    public static void setDBPathName(String pathName)
    {
        System.out.println("Setting DB path to: " + pathName);
        dbPathName = pathName;
    }


}
