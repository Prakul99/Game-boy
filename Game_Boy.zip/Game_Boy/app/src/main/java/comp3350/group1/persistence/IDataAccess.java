package comp3350.group1.persistence;

import java.util.List;

import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;

public interface IDataAccess
{
    /**
     * Initialize our data access
     */
    void open();

    /**
     * Close our data access
     */
    void close();

    /**
     * Fill a given list with all RateUpgrades in storage.
     * @param result The list to fill with all RateUpgrades.
     */
    void getAllRateUpgrades(List<IPurchasableEffect> result);

    /**
     * Fill a given list with all ClickUpgrades in storage.
     * @param result The list to fill with all ClickUpgrades.
     */
    void getAllClickUpgrades(List<IPurchasableEffect> result);

    /**
     * @param id the ID of the GameState we want.
     * @return the GameState with given ID.
     */
    GameState getGameState(int id);

    /**
     * Create a new GameState.
     * @return ID of the newly created GameState.
     */
    int createNewGameState();

    /**
     * Deletes a savegame from storage from a given ID
     */
    void deleteSaveGame(int id);

    /**
     * @param state the state we wish to write to storage.
     */
    void saveGameState(GameState state);

    /**
     * Fills a given list with all states in storage.
     * @param states the list to fill with all states.
     */
    void getAllSavedStates(List<GameState> states);
}
