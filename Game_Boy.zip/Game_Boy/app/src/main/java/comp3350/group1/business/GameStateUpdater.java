package comp3350.group1.business;

import java.util.Timer;
import java.util.TimerTask;

import comp3350.group1.objects.GameState;
import comp3350.group1.objects.ClickUpgrade;
import comp3350.group1.objects.IPurchasableEffect;
import comp3350.group1.objects.RateUpgrade;

/**
 * This class is used to manage a GameState that is actively being played.
 */
public class GameStateUpdater
{
    // We want to pass 16ms through to the GameState update.
    private static final int TIMESTEP_MILLIS = 16;

    // The state we are manipulating.
    private GameState state;

    private Timer timer;

    private boolean hasUpdatedSinceLastCheck;

    /**
     * @param state The state we will manipulate.
     */
    public GameStateUpdater(GameState state)
    {
        if(state == null) throw new IllegalArgumentException("state cannot be null");
        this.state = state;
    }

    /**
     * @return the GameState the updater is working on.
     */
    public GameState getGameState()
    {
        return state;
    }

    /**
     * This will begin running our update loop on the state.
     */
    public void startUpdating()
    {
        if(timer != null) throw new IllegalStateException("GameState is already updating");

        // Update the GameState with a given time step.
        // NOTE: this is not exactly accurate with the timing, but it doesn't need to be.
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask()
      {
            @Override
            public void run()
            {
                state.update((double)TIMESTEP_MILLIS / 1000.0);
                hasUpdatedSinceLastCheck = true;
            }
        },
        TIMESTEP_MILLIS,
        TIMESTEP_MILLIS);
    }

    /**
     * @return whether our GameState is currently updating.
     */
    public boolean isUpdating()
    {
        // The timer will be null if the state is not updating.
        return timer != null;
    }

    /**
     * Terminates the GameState updates.
     * This should be used when the state is no longer in use (saving, exiting, etc.)
     */
    public void stopUpdating()
    {
        if(timer == null) throw new IllegalStateException("GameState is already not updating");
        timer.cancel();
        timer = null;
    }

    public boolean hasUpdatedSinceLastCheck()
    {
        if(hasUpdatedSinceLastCheck)
        {
            hasUpdatedSinceLastCheck = false;
            return true;
        }
        return false;
    }

    /**
     * @return the current GameState's currency.
     */
    public long getCurrentCurrency()
    {
        return state.getCurrency();
    }

    /**
     * @return the current GameState's currencyPerSecond.
     */
    public long getCurrencyPerSecond()
    {
        return (long)state.getCurrencyPerSecond();
    }

    /**
     *  Manually increments the current GameState's currency.
     */
    public void addCurrencyOnClick()
    {
        state.incrementCurrency(state.getClickBonus());
    }

    /**
     * @param upgrade the upgrade to check the cost of.
     * @return the amount the upgrade will cost to purchase.
     */
    public long getUpgradeCost(IPurchasableEffect upgrade)
    {
        return state.getUpgradeCost(upgrade);
    }

    /**
     * @param type the upgrade we want to purchase.
     * @return whether we succeeded in adding an upgrade to the GameState.
     */
    public boolean addUpgrade(IPurchasableEffect type)
    {
        return state.buyUpgrade(type);
    }


    /**
     * @param type the upgrade we want to refund.
     * @return whether we succeeded in selling the upgrade.
     */
    public boolean sellUpgrade(IPurchasableEffect type){ return state.sellUpgrades(type);}
    /**
     * @param upgrade the upgrade to check the quantity of.
     * @return the quantity of an upgrade that has been purchased in the current GameState.
     */
    public int getUpgradeQuantity(IPurchasableEffect upgrade){ return state.getUpgradeQuantity(upgrade);}

    public int getTotalClickBonus(){return state.getClickBonus();};
}
