package comp3350.group1.integration;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;

import comp3350.group1.RestoreTestDBScript;
import comp3350.group1.application.Services;
import comp3350.group1.business.AccessGameState;
import comp3350.group1.business.AccessUpgrades;
import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;

public class BusinessPersistenceSeamTest extends TestCase
{
	public BusinessPersistenceSeamTest(String arg0)
	{
		super(arg0);
	}

	public void testAccessGameState()
	{
		AccessGameState ags;
		GameState state;
		int result;
		List<GameState> states = new ArrayList<>();

		Services.closeDataAccess();
		RestoreTestDBScript.restoreTestDB();

		System.out.println("\nStarting Integration test of AccessStudents to persistence");

		Services.createDataAccess(IntegrationTests.DATA_ACCESS_TYPE);

		ags = new AccessGameState();

		state = ags.getGameState(0);
		assertEquals(0, (state.getId()));

		ags.deleteGame(2);
		assertNull(ags.getGameState(2));
		
		result = ags.createNewGameState();
		assertEquals(2,result);
		state = ags.getGameState(2);
		assertEquals(2, (state.getId()));
		
		state = ags.getGameState(50);
		assertNull(state);

		ags.createNewGameState();
		//allGameStates
		ags.getAllSavedStates(states);
		assertEquals(4,states.size());
		ags.deleteGame(3);


		// Need to add some more tests to exercise all CRUD operations
		
		Services.closeDataAccess();
		RestoreTestDBScript.restoreTestDB();

		System.out.println("Finished Integration test of AccessStudents to persistence");
	}

	public void testAccessUpgrades(){
		AccessUpgrades au;
		AccessGameState ags;
		GameState state;

		List<IPurchasableEffect> upgrades = new ArrayList<>();

		List<IPurchasableEffect> clickUpgrades = new ArrayList<>();

		Services.closeDataAccess();
		RestoreTestDBScript.restoreTestDB();

		System.out.println("\nStarting Integration test of AccessStudents to persistence");

		Services.createDataAccess(IntegrationTests.DATA_ACCESS_TYPE);

		ags = new AccessGameState();
		au = new AccessUpgrades();

		au.getAllRateUpgrades(upgrades);
		assertEquals(24,upgrades.size());

		au.getAllClickUpgrades(clickUpgrades);
		assertEquals(21, clickUpgrades.size());

		state = ags.getGameState(1);

		au.getUnlockedRateUpgrades(upgrades, state);

		assertEquals(2, upgrades.size());

		au.getUnlockedClickUpgrades(clickUpgrades, state);
		assertEquals(1, clickUpgrades.size());

		Services.closeDataAccess();
		RestoreTestDBScript.restoreTestDB();
	}


}