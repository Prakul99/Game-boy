package comp3350.group1.business;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.HashMap;

import comp3350.group1.objects.GameState;

public class GameStateAutoSaverTest extends TestCase
{
    GameState state;
    Timestamp now;
    @Before
    public void setUp()
    {
        now = new Timestamp(System.currentTimeMillis());
        state = new GameState(0, now, now, 0, 0, new HashMap<>());
    }
    
    @Test
    public void testInvalidGameStateAutoSaver()
    {
        try
        {
            GameStateAutoSaver gameStateAutoSaver = new GameStateAutoSaver(true,null);
            fail("Expected IllegalArgumentException");
        }
        catch (IllegalArgumentException iae)
        {
            //expected
        }

        try
        {
            GameStateAutoSaver gameStateAutoSaver = new GameStateAutoSaver(true,state, 0);
            fail("Expected IllegalArgumentException");
        }
        catch (IllegalArgumentException iae)
        {
            //expected
        }
    }
    @Test
    public void testHasSavedSinceLast()
    {
        GameStateAutoSaver gameStateAutoSaver = new GameStateAutoSaver(true,state);
        assertFalse(gameStateAutoSaver.hasSavedSinceLastCheck());
        //Not sure how to test the internal timer of the updater
        //it is a dependency we are not supposed to know about externally.
        //some feedback on implementing tests for this sort of method would be appreciated
    }

    @Test
    public void testIsEnabled()
    {
        GameStateAutoSaver gameStateAutoSaver = new GameStateAutoSaver(true,state);
        assertTrue(gameStateAutoSaver.isEnabled());

        gameStateAutoSaver.disable();
        assertFalse(gameStateAutoSaver.isEnabled());

        gameStateAutoSaver.enable();
        assertTrue(gameStateAutoSaver.isEnabled());
    }

    @Test
    public void testDisabled()
    {
        try
        {
            GameStateAutoSaver gameStateAutoSaver1 = new GameStateAutoSaver(false,state);
            gameStateAutoSaver1.disable();
            fail("Expected IllegalStateException");
        }
        catch (IllegalStateException e)
        {
            //expected
        }
        GameStateAutoSaver gameStateAutoSaver = new GameStateAutoSaver(true,state);
        gameStateAutoSaver.disable();
        assertFalse(gameStateAutoSaver.isEnabled());
    }

    @Test
    public void testEnable()
    {
        try
        {
            GameStateAutoSaver gameStateAutoSaver1 = new GameStateAutoSaver(true,state);
            gameStateAutoSaver1.enable();
            fail("Expected IllegalStateException");
        }
        catch (IllegalStateException e)
        {
            //expected
        }

        GameStateAutoSaver gameStateAutoSaver = new GameStateAutoSaver(false,state);
        gameStateAutoSaver.enable();
        assertTrue(gameStateAutoSaver.isEnabled());
    }
}
