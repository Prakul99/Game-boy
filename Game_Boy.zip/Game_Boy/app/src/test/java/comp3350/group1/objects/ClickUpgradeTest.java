package comp3350.group1.objects;
import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class ClickUpgradeTest extends TestCase
{
    ClickUpgrade clickUpgrade;
    @Before
    public void setUp()
    {
        clickUpgrade = new ClickUpgrade(1, "Finger Strength", 1, 25, 1.08, null);
    }
    @Test
    public void testInvalidState()
    {
        try
        {
            ClickUpgrade u = new ClickUpgrade(0,"Finger Strength",10,10,1.15, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to id 0
        }

        try
        {
            ClickUpgrade u = new ClickUpgrade(1,"Finger Strength",-1,10,1.2, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to negative per-second increase
        }

        try
        {
            ClickUpgrade u = new ClickUpgrade(1, "Finger Strength",0,10,1.1, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to 0 per second increase
        }

        try
        {
            ClickUpgrade u = new ClickUpgrade(1, "Finger Strength",1,10,-1, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to negative cost multiplier
        }

        try
        {
            ClickUpgrade u = new ClickUpgrade(1, "Finger Strength",1,0,10, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to base cost 0
        }

    }
    @Test
    public void testType()
    {
        assertEquals(1, clickUpgrade.getId());
    }

    @Test
    public void testName()
    {
        assertEquals("Finger Strength", clickUpgrade.getName());
    }

    @Test
    public void testBaseCost()
    {
        assertEquals(25, clickUpgrade.getBaseCost());
    }

    @Test
    public void testCostMultiplier()
    {
        assertEquals(1.08, clickUpgrade.getCostMultiplier(), 0);
    }

    @Test
    public void testClickBonus() { assertEquals(1, clickUpgrade.getEffectAmount(), 0);}
}
