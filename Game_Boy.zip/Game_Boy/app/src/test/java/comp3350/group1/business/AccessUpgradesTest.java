package comp3350.group1.business;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import comp3350.group1.application.Services;
import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;
import comp3350.group1.objects.RateUpgrade;
import comp3350.group1.objects.UnlockRule;
import comp3350.group1.persistence.IDataAccess;

import static org.junit.Assert.assertNotEquals;


public class AccessUpgradesTest extends TestCase
{
    IDataAccess data;
    AccessUpgrades upgradesAccess;


    @Before
    public void setUp(){
        data = Services.createDataAccess(Services.DataStorage.Stub);
        upgradesAccess = new AccessUpgrades();
    }

    @After
    public void destroy()
    {
        Services.closeDataAccess();
    }

    @Test
    public void testGetNullUpgrade()
    {
        try
        {
            upgradesAccess.getAllRateUpgrades(null);
            fail("Expected NullPointerException");
        }
        catch(NullPointerException e)
        {
            //expected
        }
    }

    @Test
    public void testGetAllUpgradeWithEmptyList()
    {
        List<IPurchasableEffect> upgrades = new ArrayList<>();
        upgradesAccess.getAllRateUpgrades(upgrades);

        assertNotNull(upgrades);
        assertNotEquals(0, upgrades.size());
    }

    @Test
    public void testGetAllUpgradeWithOneUpgrade()
    {
        IPurchasableEffect upgrade = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        List<IPurchasableEffect> upgradesList1 = new ArrayList<>();
        List<IPurchasableEffect> upgradesList2 = new ArrayList<>();

        upgradesList1.add(upgrade);
        upgradesAccess.getAllRateUpgrades(upgradesList1);

        upgradesAccess.getAllRateUpgrades(upgradesList2);

        assertEquals(upgradesList1.size(),upgradesList2.size());
    }

    @Test
    public void testUnlockingUpgrade()
    {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        UnlockRule rule1 = new UnlockRule(0,0,0,0,0);
        IPurchasableEffect upgrade1 = new RateUpgrade(401, "Documentation Lookup", 1000, 320, 1.25, rule1);
        GameState state = new GameState(1, now, now);
        state.buyUpgrade(upgrade1);

        List<IPurchasableEffect> upgradesList1 = new ArrayList<>();
        List<IPurchasableEffect> upgradesList2 = new ArrayList<>();

        upgradesAccess.getAllRateUpgrades(upgradesList1);
        upgradesAccess.getUnlockedRateUpgrades(upgradesList2, state);
        assertTrue(upgradesList1.size() > upgradesList2.size());
    }
}