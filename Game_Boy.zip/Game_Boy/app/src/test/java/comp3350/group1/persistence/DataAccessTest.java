package comp3350.group1.persistence;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;

public class DataAccessTest extends TestCase
{
    private IDataAccess dataAccess;

    public DataAccessTest(String arg0)
    {
        super(arg0);
    }

    public void setUp()
    {
        System.out.println("\nStarting persistence test DataAccess (using stub)");

        dataAccess = new DataAccessStub();
        dataAccess.open();
    }

    public void tearDown()
    {
        System.out.println("Finished persistence test DataAccess (using stub)");
    }

    /**
     * This code runs the test on the given IDataAccess object.
     * @param dataAccess
     */
    public static void dataAccessTest(IDataAccess dataAccess)
    {
        DataAccessTest dataAccessTest = new DataAccessTest("");
        dataAccessTest.dataAccess = dataAccess;

        dataAccessTest.testSaveData();
        dataAccessTest.testUpgrades();
    }

    public void testSaveData()
    {
        int stateId;

        // Test add game state
        stateId = dataAccess.createNewGameState();
        assertEquals(3, stateId);

        // Test get game state
        GameState validState = dataAccess.getGameState(stateId);
        assertNotNull(validState);

        // Check that the stateId + 1 doesn't exist
        // Game state IDs can only increase, and new ones are 1 larger than the current largest.
        // There should be no existing state with ID greater than the one just created.
        GameState invalidState = dataAccess.getGameState(4);
        assertNull(invalidState);

        // Add money to the game state
        validState.incrementCurrency(1000);
        assertEquals(1000, validState.getCurrency());

        // Test save game state and check that currency data is accurate.
        dataAccess.saveGameState(validState);
        assertEquals(1000, dataAccess.getGameState(stateId).getCurrency());

        // Test delete game state
        dataAccess.deleteSaveGame(stateId);

        // Ensure that the size of the list is the same when deleting a nonexistent id.
        List<GameState> gameStateList = new ArrayList<>();
        dataAccess.getAllSavedStates(gameStateList);
        int numSaves = gameStateList.size();
        assertEquals(3, numSaves);

        dataAccess.deleteSaveGame(stateId); // Attempt to delete an already-deleted id.
        dataAccess.getAllSavedStates(gameStateList);
        assertEquals(3, gameStateList.size());
    }

    public void testUpgrades()
    {
        // Test getting upgrades
        ArrayList<IPurchasableEffect> upgrades = new ArrayList<>();
        dataAccess.getAllRateUpgrades(upgrades);
        assertEquals(24, upgrades.size());

        // Test adding upgrades to a game state.
        int stateId = dataAccess.createNewGameState();
        assertEquals(3, stateId);
        GameState testState = dataAccess.getGameState(stateId);
        assertNotNull(testState); // repeat this assert from the other integration test.

        IPurchasableEffect sampleUpgrade = upgrades.get(0);
        int upgradeId = sampleUpgrade.getId();
        assertEquals(100, upgradeId);

        double perSecondIncrease = sampleUpgrade.getEffectAmount();
        assertEquals(1.0, perSecondIncrease);

        long upgradeCost = sampleUpgrade.getBaseCost();
        assertEquals(10, upgradeCost);

        double costMultiplier = sampleUpgrade.getCostMultiplier();
        assertEquals(1.30, costMultiplier);

        // Buying with insufficient currency should fail.
        assertFalse(testState.buyUpgrade(sampleUpgrade));
        assertEquals(0, testState.getUpgradeQuantity(upgradeId));

        // Buying should succeed if we have enough currency
        testState.incrementCurrency(10);
        assertTrue(testState.buyUpgrade(sampleUpgrade));
        assertEquals(1, testState.getUpgradeQuantity(upgradeId));

        // The one upgrade should be the sole contributor to currency gained per second.
        assertEquals(1.0, testState.getCurrencyPerSecond());

        // Ensure that upgrades are properly saved to states in the data access.
        dataAccess.saveGameState(testState);
        GameState loadedState = dataAccess.getGameState(stateId);
        HashMap<Integer, Integer> allUpgradeMapping = loadedState.getAllUpgradeMapping();
        assertTrue(allUpgradeMapping.containsKey(upgradeId));
        if(allUpgradeMapping.containsKey(upgradeId))
            assertEquals(1, (int) allUpgradeMapping.get(upgradeId));
    }
}
