package comp3350.group1.objects;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class RateUpgradeTest extends TestCase
{
    RateUpgrade upgrade;

    @Before
    public void setUp()
    {
        upgrade = new RateUpgrade(1, "Additional Developers", 1, 25, 1.08, null);
    }

    @Test
    public void testInvalidState()
    {
        try
        {
            RateUpgrade u = new RateUpgrade(0,"Additional Developers",10,10,1.15, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to id 0
        }

        try
        {
            RateUpgrade u = new RateUpgrade(1,"Additional Developers",-1,10,1.2, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to negative per-second increase
        }

        try
        {
            RateUpgrade u = new RateUpgrade(1, "Additional Developers",0,10,1.1, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to 0 per second increase
        }

        try
        {
            RateUpgrade u = new RateUpgrade(1, "Additional Developers",1,10,-1, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to negative cost multiplier
        }

        try
        {
            RateUpgrade u = new RateUpgrade(1, "Additional Developers",1,0,10, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException npe)
        {
            //expected due to base cost 0
        }

    }
    @Test
    public void testType()
    {
        assertEquals(1, upgrade.getId());
    }

    @Test
    public void testName()
    {
        assertEquals("Additional Developers", upgrade.getName());
    }

    @Test
    public void testPerSecondIncrease()
    {
        assertEquals(1, upgrade.getEffectAmount(), 0);
    }

    @Test
    public void testBaseCost()
    {
        assertEquals(25, upgrade.getBaseCost());
    }

    @Test
    public void testCostMultiplier()
    {
        assertEquals(1.08, upgrade.getCostMultiplier(), 0);
    }
}
