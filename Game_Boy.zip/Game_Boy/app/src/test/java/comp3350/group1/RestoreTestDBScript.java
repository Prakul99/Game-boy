package comp3350.group1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class RestoreTestDBScript
{
    public static void restoreTestDB()
    {
        try
        {
            FileInputStream inputStream = new FileInputStream("database/tests_restore_SC.script");
            FileOutputStream outputStream = new FileOutputStream("database/SC.script");

            int copy;
            while((copy = inputStream.read()) != -1)
                outputStream.write(copy);

            inputStream.close();
            outputStream.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
