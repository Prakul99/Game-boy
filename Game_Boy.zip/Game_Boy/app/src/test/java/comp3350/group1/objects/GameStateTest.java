package comp3350.group1.objects;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class GameStateTest extends TestCase
{
    Timestamp now;
    @Before
    public void setUp()
    {
        now = new Timestamp(System.currentTimeMillis());
    }

    @Test
    public void testValidState()
    {
        GameState state = new GameState(0, now, now);
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 25, 1.1, null);

        assertEquals(0, state.getId());
        assertEquals(0.0, state.getCurrency(), 0);
        assertEquals(0.0, state.getCurrencyPerSecond(), 0);
        assertEquals(25, state.getUpgradeCost(u1));
        assertEquals(0, state.getUpgradeQuantity(u1));
        assertEquals(0, state.getAllUpgradeMapping().size());
        assertEquals(now, state.getCurrentTime());
        assertEquals(now, state.getCreationTime());

        //testing both versions of the constructor
        state = new GameState(0, now, now, 0, 0, new HashMap<>());

        assertEquals(0, state.getId());
        assertEquals(0, state.getCurrency(), 0);
        assertEquals(0, state.getCurrencyPerSecond(), 0);
        assertEquals(25, state.getUpgradeCost(u1));
        assertEquals(0, state.getUpgradeQuantity(u1));
        assertEquals(0, state.getAllUpgradeMapping().size());
        assertEquals(now, state.getCurrentTime());
        assertEquals(now, state.getCreationTime());
    }

    @Test
    public void testInvalidState()
    {
        try
        {
            GameState state  = new GameState(-1,now, now,0, 0, new HashMap<>());
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException iae)
        {
            //expected
        }

        try
        {
            GameState state  = new GameState(-1,null, now,0, 0, new HashMap<>());
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException iae)
        {
            //expected
        }

        try
        {
            GameState state  = new GameState(-1,now, null, 0, 0, new HashMap<>());
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException iae)
        {
            //expected
        }

        try
        {
            GameState state  = new GameState(0, now, now, -1, 0, new HashMap<>());
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException iae)
        {
            //expected
        }

        try
        {
            GameState state  = new GameState(0, now, now, 0, 0, null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException iae)
        {
            //expected
        }
    }

    @Test
    public void testValidUpgrade()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        GameState state = new GameState(0, now, now);

        assertEquals(u1.getBaseCost(), state.getUpgradeCost(u1));

        boolean upgradeSuccess = state.buyUpgrade(u1);
        assertFalse(upgradeSuccess);

        state.incrementCurrency(10);
        upgradeSuccess = state.buyUpgrade(u1);
        assertTrue(upgradeSuccess);

        long cost = (long)(u1.getBaseCost() * u1.getCostMultiplier());
        assertEquals(cost, state.getUpgradeCost(u1));
    }

    @Test
    public void testInvalidUpgrade()
    {
        GameState state = new GameState(0, now, now);
        try
        {
            state.buyUpgrade(null);
            fail("Expected NullPointerException");
        }
        catch(NullPointerException e)
        {
        }

    }

    @Test
    public void testUpgrading()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers",1, 50, 1.1, null);
        RateUpgrade u2 = new RateUpgrade(2, "Available Threads", 5, 100, 1.1, null);

        GameState state = new GameState(0, now, now, 500, 0, new HashMap<>());

        assertEquals(0, state.getCurrencyPerSecond(), 0);

        boolean success = state.buyUpgrade(u1);
        assertTrue(success);
        assertEquals(1, state.getCurrencyPerSecond(), 0);

        // The base click bonus is 1. Buying a rate upgrade should not affect click bonus
        assertEquals(1, state.getClickBonus());

        assertEquals(450, state.getCurrency(), 0);

        success = state.buyUpgrade(u2);
        assertTrue(success);
        assertEquals(6, state.getCurrencyPerSecond(), 0);

        // The base click bonus is 1. Buying a rate upgrade should not affect click bonus
        assertEquals(1, state.getClickBonus());
        assertEquals(350, state.getCurrency(), 0);
    }

    @Test
    public void testCurrencyIncrement()
    {
        RateUpgrade upgrade = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);

        GameState state = new GameState(0, now, now);
        assertEquals(0, state.getCurrency(), 0);

        state.incrementCurrency(5);
        assertEquals(5, state.getCurrency(), 0);

        //should fail because we do not have enough currency
        boolean upgradeSuccessful = state.buyUpgrade(upgrade);
        assertFalse(upgradeSuccessful);

        state.incrementCurrency(5);
        upgradeSuccessful = state.buyUpgrade(upgrade);
        assertTrue(upgradeSuccessful);

        try
        {
            state.incrementCurrency(0);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }

        try
        {
            state.incrementCurrency(-10);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }
    }

    @Test
    public void testStateUpdating()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        GameState state = new GameState(0, now, now, 10, 0, new HashMap<>());

        try
        {
            state.update(0);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }
        try
        {
            state.update(-1);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }

        state.update(1);
        assertEquals(0, state.getCurrencyPerSecond(), 0);
        assertEquals(10, state.getCurrency(), 0);

        state.buyUpgrade(u1);
        state.update(1);

        assertEquals(u1.getEffectAmount(), state.getCurrencyPerSecond(), 0);
        assertEquals(state.getCurrency(), u1.getEffectAmount(), 0);
    }

    @Test
    public void testTotalTimePlayed()
    {
        GameState state = new GameState(0, now, now, 10, 0, new HashMap<>());
        assertEquals("0 seconds",state.totalTimePlayed());

        GameState state1 = new GameState(0, new Timestamp(123709741), new Timestamp(638215194), 10, 0, new HashMap<>());
        assertEquals("5 days, 22 hours, 55 minutes, 5 seconds",state1.totalTimePlayed());
    }

    @Test
    public void testInvalidTotalTimePlayed()
    {
        GameState state1 = new GameState(0, new Timestamp(638215194), new Timestamp(123709741), 10, 0, new HashMap<>());
        assertEquals("0 seconds",state1.totalTimePlayed());
    }

    @Test
    public void testBuyUpgrade()
    {
        GameState state = new GameState(0, now, now, 100, 0, new HashMap<>());
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 25, 1.1, null);

        state.buyUpgrade(u1);
        assertEquals(75,state.getCurrency());
    }

    @Test
    public void testBuyClickUpgrade()
    {
        GameState state = new GameState(0, now, now, 100, 0, new HashMap<>());
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 1, 75, 1.08, null);

        state.buyUpgrade(clickUpgrade);
        assertEquals(25,state.getCurrency());
    }

    @Test
    public void testSellUpgrade()
    {
        GameState state = new GameState(0, now, now, 100, 0, new HashMap<>());
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 25, 1.1, null);
        assertFalse(state.sellUpgrades(u1));

        state.buyUpgrade(u1);
        assertTrue(state.sellUpgrades(u1));
    }

    @Test
    public void testSellClickUpgrade()
    {
        GameState state = new GameState(0, now, now, 100, 0, new HashMap<>());
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 1, 75, 1.08, null);
        assertFalse(state.sellUpgrades(clickUpgrade));

        assertTrue(state.buyUpgrade(clickUpgrade));
        assertTrue(state.sellUpgrades(clickUpgrade));
    }

    @Test
    public void testTotalClickBonus()
    {
        GameState state = new GameState(0, now, now, 100, 0, new HashMap<>());
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);

        state.buyUpgrade(clickUpgrade);
        assertEquals(4, state.getClickBonus());
        assertEquals(0.0, state.getCurrencyPerSecond());

        state.sellUpgrades(clickUpgrade);
        assertEquals(1, state.getClickBonus());
    }

    @Test
    public void testClickUpgradeQuantity()
    {
        GameState state = new GameState(0, now, now, 5000, 0, new HashMap<>());
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);

        state.buyUpgrade(clickUpgrade);
        state.buyUpgrade(clickUpgrade);
        state.buyUpgrade(clickUpgrade);
        state.buyUpgrade(clickUpgrade);

        assertEquals(4, state.getUpgradeQuantity(clickUpgrade));
    }

    @Test
    public void testUpgradeQuantity()
    {
        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 25, 1.1, null);

        state.buyUpgrade(u1);
        state.buyUpgrade(u1);
        state.buyUpgrade(u1);
        state.buyUpgrade(u1);
        state.buyUpgrade(u1);
        state.buyUpgrade(u1);

        assertEquals(6, state.getUpgradeQuantity(u1));
    }

}
