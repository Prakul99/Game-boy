package comp3350.group1.business;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.HashMap;

import comp3350.group1.objects.ClickUpgrade;
import comp3350.group1.objects.GameState;
import comp3350.group1.objects.RateUpgrade;


public class GameStateUpdaterTest extends TestCase
{
    Timestamp now;

    @Before
    public void setUp()
    {
        now = new Timestamp(System.currentTimeMillis());
    }

    @Test
    public void testValidState()
    {
        GameState state = new GameState(0, now, now);

        GameStateUpdater updater = new GameStateUpdater(state);

        assertNotNull(updater);
        assertEquals(state, updater.getGameState());
    }

    @Test
    public void testInvalidState()
    {
        try
        {
            GameStateUpdater updater = new GameStateUpdater(null);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }

        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now));
        assertFalse(updater.isUpdating());

        try
        {
            updater.stopUpdating();

            fail("Expected IllegalStateException");
        }
        catch(IllegalStateException e)
        {
            //expected
        }

        updater.startUpdating();
        assertTrue(updater.isUpdating());
        try
        {
            updater.startUpdating();
            fail("Expected IllegalStateException");
        }
        catch(IllegalStateException e)
        {
            //expected
        }
        updater.stopUpdating();
        assertFalse(updater.isUpdating());
    }

    @Test
    public void testCurrentCurrency()
    {
        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now));

        assertEquals(0, updater.getCurrentCurrency());

        updater.addCurrencyOnClick();
        assertEquals(1, updater.getCurrentCurrency());

        updater.addCurrencyOnClick();
        assertEquals(2, updater.getCurrentCurrency());
    }

    @Test
    public void testCurrencyPerSecond()
    {
        RateUpgrade upgrade = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now, 10, 0, new HashMap<>()));

        assertEquals(0, updater.getCurrencyPerSecond());
        assertEquals(10, updater.getCurrentCurrency());

        updater.addUpgrade(upgrade);

        assertEquals(1, updater.getCurrencyPerSecond());
        assertEquals(0, updater.getCurrentCurrency());
    }

    @Test
    public void testUpgradeNull()
    {
        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now));

        try
        {
            updater.getUpgradeCost(null);
            fail("Expected NullPointerException");
        }
        catch(NullPointerException e)
        {
            //expected
        }

        try
        {
            updater.addUpgrade(null);
            fail("Expected NullPointerException");
        }
        catch(NullPointerException e)
        {
            //expected
        }
    }

    @Test
    public void testUpgradeValid()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        RateUpgrade u2 = new RateUpgrade(2, "Available Threads", 5, 50, 1.5, null);

        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now,100, 0, new HashMap<>()));

        assertEquals(u1.getBaseCost(), updater.getUpgradeCost(u1));
        assertEquals(u2.getBaseCost(), updater.getUpgradeCost(u2));

        updater.addUpgrade(u1);
        double cost = u1.getBaseCost() * u1.getCostMultiplier();

        assertEquals(cost, updater.getUpgradeCost(u1), 0);
        assertEquals(u2.getBaseCost(), updater.getUpgradeCost(u2), 0);
        assertEquals(updater.getCurrentCurrency(), 90);

        updater.addUpgrade(u2);
        cost = u2.getBaseCost() * u2.getCostMultiplier();
        assertEquals(cost, updater.getUpgradeCost(u2), 0);
        assertEquals(updater.getCurrentCurrency(), 40);
    }

    @Test
    public void testUpgradeFail()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        RateUpgrade u2 = new RateUpgrade(2, "Available Threads", 5, 50, 1.5, null);

        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now, 0, 0, new HashMap<>()));

        boolean upgradeSuccess = updater.addUpgrade(u1);
        assertFalse(upgradeSuccess);

        upgradeSuccess = updater.addUpgrade(u2);
        assertFalse(upgradeSuccess);
    }

    @Test
    public void testGetUpgradeCost()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        RateUpgrade u2 = new RateUpgrade(2, "Available Threads", 5, 50, 1.5, null);
        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now, 0, 0, new HashMap<>()));

        assertEquals(10,updater.getUpgradeCost(u1));
        assertEquals(50,updater.getUpgradeCost(u2));
    }

    @Test
    public void testGetClickUpgradeCost()
    {
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);
        GameStateUpdater updater = new GameStateUpdater(new GameState(0, now, now, 0, 0, new HashMap<>()));
        assertEquals(75,updater.getUpgradeCost(clickUpgrade));

        ClickUpgrade clickUpgrade2 = new ClickUpgrade(1, "Gainz", 3, 120, 1.08, null);
        assertEquals(120,updater.getUpgradeCost(clickUpgrade2));
    }

    @Test
    public void testAddUpgrade()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        RateUpgrade u2 = new RateUpgrade(2, "Available Threads", 5, 50, 1.5, null);
        RateUpgrade u3 = new RateUpgrade(1, "Code Farm", 1, 1200, 1.1, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        assertTrue(updater.addUpgrade(u1));
        assertTrue(updater.addUpgrade(u2));
        assertFalse(updater.addUpgrade(u3));
    }

    @Test
    public void testAddClickUpgrade()
    {
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);
        ClickUpgrade clickUpgrade1 = new ClickUpgrade(1, "Gainz", 3, 75, 1.08, null);
        ClickUpgrade clickUpgrade2 = new ClickUpgrade(1, "Gaming mouse", 3, 1200, 1.08, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        assertTrue(updater.addUpgrade(clickUpgrade));
        assertTrue(updater.addUpgrade(clickUpgrade1));
        assertFalse(updater.addUpgrade(clickUpgrade2));
    }

    @Test
    public void testSellupgrade()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);
        RateUpgrade u2 = new RateUpgrade(2, "Available Threads", 5, 50, 1.5, null);
        RateUpgrade u3 = new RateUpgrade(1, "Code Farm", 1, 1200, 1.1, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        updater.addUpgrade(u1);
        updater.addUpgrade(u2);

        assertTrue(updater.sellUpgrade(u1));
        assertTrue(updater.sellUpgrade(u2));
        assertFalse(updater.sellUpgrade(u3));
    }

    @Test
    public void testSellClickUpgrade()
    {
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);
        ClickUpgrade clickUpgrade1 = new ClickUpgrade(1, "Gainz", 3, 75, 1.08, null);
        ClickUpgrade clickUpgrade2 = new ClickUpgrade(1, "Gaming mouse", 3, 1200, 1.08, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        updater.addUpgrade(clickUpgrade);
        updater.addUpgrade(clickUpgrade1);

        assertTrue(updater.sellUpgrade(clickUpgrade));
        assertTrue(updater.sellUpgrade(clickUpgrade1));
        assertFalse(updater.sellUpgrade(clickUpgrade2));
    }

    @Test
    public void testUpgradeQuantity()
    {
        RateUpgrade u1 = new RateUpgrade(1, "Additional Developers", 1, 10, 1.1, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        updater.addUpgrade(u1);
        updater.addUpgrade(u1);

        assertEquals(2,updater.getUpgradeQuantity(u1));
    }

    @Test
    public void testClickUpgradeQuantity()
    {
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        updater.addUpgrade(clickUpgrade);
        updater.addUpgrade(clickUpgrade);

        assertEquals(2,updater.getUpgradeQuantity(clickUpgrade));
    }

    @Test
    public void testTotalClickBonus()
    {
        ClickUpgrade clickUpgrade = new ClickUpgrade(1, "Finger Strength", 3, 75, 1.08, null);

        GameState state = new GameState(0, now, now, 1000, 0, new HashMap<>());
        GameStateUpdater updater = new GameStateUpdater(state);

        updater.addUpgrade(clickUpgrade);

        assertEquals(4,updater.getTotalClickBonus());
    }

}
