package comp3350.group1.business;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.ArrayList;

import comp3350.group1.application.Services;
import comp3350.group1.objects.GameState;
import comp3350.group1.persistence.IDataAccess;


public class AccessGameStateTest extends TestCase
{
    AccessGameState accessGame;
    IDataAccess data;

    @Before
    public void setUp()
    {
        data = Services.createDataAccess(Services.DataStorage.Stub);
        accessGame = new AccessGameState();
    }

    @After
    public void destroy()
    {
        Services.closeDataAccess();
    }

    @Test
    public void testValidID()
    {
        int ID = accessGame.createNewGameState();

        assertTrue(ID >= 0);
    }


    @Test
    public void testSavedGame()
    {
	    int ID = accessGame.createNewGameState();
	    GameState state = accessGame.getGameState(ID);

	    assertNotNull(state);

	    ArrayList<GameState> savedStates = new ArrayList<>();
	    data.getAllSavedStates(savedStates);

	    boolean saved = savedStates.contains(state);
	    assertTrue(saved);

	    accessGame.saveGame(state);
        data.getAllSavedStates(savedStates);

        saved = savedStates.contains(state);
        assertTrue(saved);
    }


    @Test
    public void testGameStateAccess()
    {
        try
        {
            GameState state = accessGame.getGameState(-1);
            fail("Expected IllegalArgumentException");
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }

        ArrayList<GameState> states = new ArrayList<>();
        accessGame.getAllSavedStates(states);

        //there should always be test data, so the size should be greater than 0 ?
        assertTrue(states.size() > 0);

        for(GameState s : states)
        {
            assertNotNull(s);
        }

        GameState state2 = data.getGameState(states.get(0).getId());
        assertEquals(states.get(0), state2);
    }


    @Test
    public void testGameStatesEmptyList()
    {
        ArrayList<GameState> states1 = new ArrayList<>();
        ArrayList<GameState> states2 = new ArrayList<>();

        data.getAllSavedStates(states1);

        accessGame.getAllSavedStates(states2);

        assertEquals(states1, states2);
    }

    @Test
    public void testGameStatesFilledList()
    {
        Timestamp now = new Timestamp(System.currentTimeMillis());

        ArrayList<GameState> states1 = new ArrayList<>();
        states1.add(new GameState(0, now, now));
        states1.add(new GameState(1, now, now));
        states1.add(new GameState(2, now, now));

        ArrayList<GameState> states2 = new ArrayList<>();

        data.getAllSavedStates(states1);
        accessGame.getAllSavedStates(states2);

        assertEquals(states1, states2);
    }
}













