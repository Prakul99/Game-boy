package comp3350.group1.integration;

import junit.framework.TestCase;

import comp3350.group1.application.Services;
import comp3350.group1.persistence.DataAccessTest;
import comp3350.group1.persistence.IDataAccess;
import comp3350.group1.RestoreTestDBScript;

public class DataAccessHSQLDBTest extends TestCase
{
    public DataAccessHSQLDBTest(String arg0)
    {
        super(arg0);
    }

    public void testDataAccess()
    {
        IDataAccess dataAccess;
        Services.closeDataAccess();
        RestoreTestDBScript.restoreTestDB();

        System.out.println("\nStarting Integration test DataAccess (using default DB)");
        Services.createDataAccess(IntegrationTests.DATA_ACCESS_TYPE);
        dataAccess = Services.getDataAccess();

        DataAccessTest.dataAccessTest(dataAccess);

        Services.closeDataAccess();
        System.out.println("Finished Integration test DataAccess (using default DB)");
        RestoreTestDBScript.restoreTestDB();
    }

}
