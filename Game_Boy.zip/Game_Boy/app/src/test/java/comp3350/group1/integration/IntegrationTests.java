package comp3350.group1.integration;

import junit.framework.Test;
import junit.framework.TestSuite;

import comp3350.group1.application.Services;

public class IntegrationTests
{
    // Change the enum type between `Database` and `Stub` to test each individually.
    public static final Services.DataStorage DATA_ACCESS_TYPE = Services.DataStorage.Database;

    public static TestSuite suite;

    public static Test suite()
    {
        suite = new TestSuite("Integration tests");
        suite.addTestSuite(BusinessPersistenceSeamTest.class);
        suite.addTestSuite(DataAccessHSQLDBTest.class);

        return suite;
    }
}
