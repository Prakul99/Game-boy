package comp3350.group1.objects;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

import java.sql.Timestamp;
import java.util.HashMap;

public class UnlockRuleTest extends TestCase
{
    Timestamp now;
    UnlockRule unlockRule;

    @Before
    public void setUp() { now = new Timestamp(System.currentTimeMillis()); }

    @Test
    public void testPerSecond()
    {
        UnlockRule rule = new UnlockRule(2,0,0,0,0);
        GameState s1 = new GameState(100, now, now, 1000000, 0, new HashMap<>());
        RateUpgrade u1 = new RateUpgrade(200, "Extra Screen Space", 4, 80, 1.15, rule);

        // Should be locked at first.
        assertEquals(false, u1.isUnlocked(s1));

        // Should be unlocked after buying the upgrade.
        s1.buyUpgrade(u1);
        assertEquals(true, u1.isUnlocked(s1));

        // Should still be unlocked even if we sell the upgrade afterwards.
        s1.sellUpgrades(u1);
        assertEquals(true, u1.isUnlocked(s1));
    }

    @Test
    public void testQuantity()
    {
        UnlockRule rule = new UnlockRule(0,0,0,200,2);
        GameState s1 = new GameState(100, now, now, 1000000, 0, new HashMap<>());
        RateUpgrade u1 = new RateUpgrade(200, "Extra Screen Space", 4, 80, 1.15, rule);

        // Should be locked at first.
        assertEquals(false, u1.isUnlocked(s1));

        // Should still be locked after buying one upgrade
        s1.buyUpgrade(u1);
        assertEquals(false, u1.isUnlocked(s1));

        // Should be unlocked after buying the second upgrade
        s1.buyUpgrade(u1);
        assertEquals(true, u1.isUnlocked(s1));
    }
}
