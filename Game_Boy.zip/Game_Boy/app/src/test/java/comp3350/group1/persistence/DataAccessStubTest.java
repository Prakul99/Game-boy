package comp3350.group1.persistence;

import junit.framework.TestCase;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import comp3350.group1.objects.GameState;
import comp3350.group1.objects.IPurchasableEffect;
import comp3350.group1.objects.RateUpgrade;

public class DataAccessStubTest extends TestCase
{
    @Test
    public void testGetAllUpgrades()
    {
        IDataAccess data = new DataAccessStub();
        data.open();
        ArrayList<IPurchasableEffect> test = new ArrayList<>();
        data.getAllRateUpgrades(test);

        assertEquals(24, test.size());
    }

    @Test
    public void testGetAllClickUpgrades()
    {
        IDataAccess data = new DataAccessStub();
        data.open();
        ArrayList<IPurchasableEffect> test = new ArrayList<>();
        data.getAllClickUpgrades(test);

        assertEquals(21, test.size());
    }

    @Test
    public void testGetGameState()
    {
        IDataAccess data = new DataAccessStub();
        data.open();
        GameState testInvalid;
        try
        {
            testInvalid = data.getGameState(-3);
            fail("IllegalArgumentException Expected");
        }
        catch (IllegalArgumentException e)
        {
            //expect exception
        }
        GameState testValid = data.getGameState(2);
        assertNotNull(testValid);
        GameState testNotExists = data.getGameState(3);
        //expect null
        assertNull(testNotExists);
    }

    @Test
    public void testCreateNewGameState()
    {
        IDataAccess data = new DataAccessStub();
        data.open();
        int id = data.createNewGameState();
        assertEquals(3, id);
    }

    @Test
    public void testDeleteSaveGame()
    {
        IDataAccess data = new DataAccessStub();
        data.open();
        List<GameState> gameStates = new ArrayList<>();

        data.getAllSavedStates(gameStates);
        assertEquals(3, gameStates.size());

        // Delete an ID that exists
        data.deleteSaveGame(2);
        assertNull(data.getGameState(2));
        data.getAllSavedStates(gameStates);
        assertEquals(2, gameStates.size());


        // Delete an ID that doesn't exist (the initial size of the data is 4)
        data.deleteSaveGame(100);
        data.getAllSavedStates(gameStates);
        assertEquals(2, gameStates.size());

    }

    @Test
    public void testGetAllSavedStates()
    {
        IDataAccess data = new DataAccessStub();
        data.open();
        List<GameState> testList = new ArrayList<>();
        data.getAllSavedStates(testList);
        assertEquals(3,testList.size());

    }
}